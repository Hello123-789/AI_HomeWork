
# 8 Puzzle
## Chạy chương trình

python main.py


## Chế độ hỗ trợ
- **BFS**
- **Simulated Annealing**

## Môi trường
- **Observable**  
  Start và Goal nhập theo kiểu:

  {
  1 2 3
  4 0 5
  7 8 6

  1 2 3
  4 5 6
  7 0 8
  }

- **Partially Observable**  
  Ô khuất dùng -1.

- **Unobservable**  
  - Mù Start: 2 Start, 1 Goal
  - Mù Goal: 1 Start, 2 Goal

