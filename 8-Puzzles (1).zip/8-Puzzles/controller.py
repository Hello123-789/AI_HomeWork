from __future__ import annotations

from dataclasses import dataclass
from typing import List, Union

from model import (
    State,
    SearchResult,
    bfs,
    simulated_annealing,
    group_bfs,
    group_simulated_annealing,
    parse_matrices,
    matrix_to_state,
    hidden_completions,
    state_heuristic,
    is_solvable,
)
from view import PuzzleView


@dataclass
class ProblemCase:
    start: State
    goal: State
    label: str = ""


@dataclass
class GroupProblemCase:
    starts: List[State]
    goals: List[State]
    label: str = ""


CaseLike = Union[ProblemCase, GroupProblemCase]


class AppController:
    def __init__(self, root, view: PuzzleView):
        self.root = root
        self.view = view
        self.results: List[SearchResult] = []
        self.cases: List[CaseLike] = []
        self.current_result_index = 0
        self._step_index_by_case: dict[int, int] = {}

        self.view.set_callbacks(self.solve, self.prev_step, self.next_step)
        self.view.set_mode_change_callback(self._sync_inputs_to_mode)
        self.view.refresh_mode_labels()
        self.view.draw_board((1, 2, 3, 4, 5, 6, 7, 8, 0))
        self.view.set_frontier_text("")
        self.view.set_reached_text("")
        self.view.set_step(0, 0)
        self._sync_inputs_to_mode()

    def _sync_inputs_to_mode(self):
        env = self.view.env_var.get()
        blind = self.view.blind_var.get()

        if env == "Observable":
            start_text = "{\n1 2 3\n4 0 5\n7 8 6\n\n1 2 3\n4 5 6\n7 0 8\n}"
            goal_text = "{\n1 2 3\n4 5 6\n7 8 0\n\n1 2 3\n4 0 5\n7 8 6\n}"
        elif env == "Partially Observable":
            if blind == "Mù Start":
                start_text = "{\n1 2 3\n4 -1 -1\n7 8 6\n}"
                goal_text = "{\n1 2 3\n4 5 6\n7 8 0\n}"
            else:
                start_text = "{\n1 2 3\n4 0 5\n7 8 6\n}"
                goal_text = "{\n1 2 3\n4 -1 -1\n7 8 0\n}"
        else:
            if blind == "Mù Start":
                start_text = "{\n1 2 3\n4 0 5\n7 8 6\n\n1 2 3\n4 5 6\n7 8 0\n}"
                goal_text = "{\n1 2 3\n4 5 6\n7 8 0\n}"
            else:
                start_text = "{\n1 2 3\n4 0 5\n7 8 6\n}"
                goal_text = "{\n1 2 3\n4 5 6\n7 8 0\n\n1 2 3\n4 0 5\n7 8 6\n}"

        self.view.start_text.text_widget.configure(state="normal")
        self.view.start_text.text_widget.delete("1.0", "end")
        self.view.start_text.text_widget.insert("1.0", start_text)
        self.view.start_text.text_widget.configure(state="normal")

        self.view.goal_text.text_widget.configure(state="normal")
        self.view.goal_text.text_widget.delete("1.0", "end")
        self.view.goal_text.text_widget.insert("1.0", goal_text)
        self.view.goal_text.text_widget.configure(state="normal")

        self.view.set_step(0, 0)
        self.view.set_status("Mẫu dữ liệu đã được cập nhật theo chế độ đang chọn.")

    def solve(self):
        try:
            cases = self._build_cases()
            if not cases:
                self.view.set_status("Không có bài toán hợp lệ.")
                return
        except Exception as e:
            self.view.set_status(f"Lỗi nhập liệu: {e}")
            return

        algo = self.view.algo_var.get().strip().upper()
        self.results = []
        self.cases = cases

        for case in cases:
            result = self._solve_case(case, algo)
            self.results.append(result)

        self.current_result_index = 0
        labels = [self._case_label(case, i) for i, case in enumerate(cases, 1)]
        self._display_current_result()
        self.view.draw_solution_forest(self.results, labels)
        if len(self.results) > 1:
            self.view.set_status(f"Đã giải xong. Đang hiển thị {len(self.results)} cây lời giải.")
        else:
            self.view.set_status("Đã giải xong. Dùng Prev/Next để xem từng bước.")

    def prev_step(self):
        self._goto_step(-1)

    def next_step(self):
        self._goto_step(1)

    def _goto_step(self, direction: int):
        if not self.results:
            return

        result = self.results[0]
        if not result.path:
            self.view.set_status("Không có đường đi để duyệt.")
            return

        step = self._step_index_by_case.get(0, 0)
        step = max(0, min(len(result.path) - 1, step + direction))
        self._step_index_by_case[0] = step

        self.view.draw_board(result.path[step])
        self.view.set_step(step, len(result.path) - 1)
        self.view.set_frontier_text(result.frontier_log[min(step, len(result.frontier_log) - 1)] if result.frontier_log else "")
        self.view.set_reached_text(result.reached_log[min(step, len(result.reached_log) - 1)] if result.reached_log else "")

    def _display_current_result(self):
        if not self.results:
            return
        result = self.results[0]
        self._step_index_by_case = {0: 0}

        if result.path:
            self.view.draw_board(result.path[0])
            self.view.set_step(0, len(result.path) - 1)
        else:
            self.view.set_step(0, 0)
            self.view.draw_board((1, 2, 3, 4, 5, 6, 7, 8, 0))

        self.view.set_frontier_text(result.frontier_log[0] if result.frontier_log else "")
        self.view.set_reached_text(result.reached_log[0] if result.reached_log else "")

    def _solve_case(self, case: CaseLike, algo: str) -> SearchResult:
        if isinstance(case, GroupProblemCase):
            if algo == "BFS":
                return group_bfs(case.starts, case.goals)
            if algo == "SIMULATED ANNEALING":
                return group_simulated_annealing(case.starts, case.goals)
            return group_bfs(case.starts, case.goals)

        if algo == "BFS":
            return bfs(case.start, case.goal)
        if algo == "SIMULATED ANNEALING":
            return simulated_annealing(case.start, case.goal)
        return bfs(case.start, case.goal)

    def _case_label(self, case: CaseLike, index: int) -> str:
        label = case.label.strip() if case.label else ""
        return label or f"Case {index}"

    def _format_case_summary(self, index: int, case: CaseLike, result: SearchResult) -> str:
        status = "THÀNH CÔNG" if result.success else "THẤT BẠI"
        if isinstance(case, GroupProblemCase):
            starts = " | ".join(f"Start {i+1}: {st}" for i, st in enumerate(case.starts))
            goals = " | ".join(f"Goal {i+1}: {gt}" for i, gt in enumerate(case.goals))
            return "\n".join(
                [
                    f"Case {index}: {status}",
                    starts,
                    goals,
                    f"Số bước: {result.steps}",
                    f"Số node đã duyệt: {result.explored}",
                    f"Thông báo: {result.message}",
                ]
            )

        return "\n".join(
            [
                f"Case {index}: {status}",
                f"Start: {case.start}",
                f"Goal:  {case.goal}",
                f"Số bước: {result.steps}",
                f"Số node đã duyệt: {result.explored}",
                f"Thông báo: {result.message}",
            ]
        )

    def _build_cases(self) -> List[CaseLike]:
        env = self.view.env_var.get()
        blind = self.view.blind_var.get()
        start_raw = self.view.get_start_raw()
        goal_raw = self.view.get_goal_raw()

        start_mats = parse_matrices(start_raw)
        goal_mats = parse_matrices(goal_raw)

        if env == "Observable":
            if len(start_mats) != 2 or len(goal_mats) != 2:
                raise ValueError("Observable cần đúng 2 ma trận ở cả Start và Goal.")
            starts = [matrix_to_state(m) for m in start_mats]
            goals = [matrix_to_state(m) for m in goal_mats]
            return [GroupProblemCase(starts, goals, "Observable 1")]

        if env == "Partially Observable":
            if len(start_mats) != 1 or len(goal_mats) != 1:
                raise ValueError("Partially Observable cần đúng 1 ma trận Start và 1 ma trận Goal.")

            if blind == "Mù Start":
                goal_state = matrix_to_state(goal_mats[0])
                candidates = hidden_completions(start_mats[0])
                cases = self._pick_candidates(candidates, goal_state, start_side=True)
                if not cases:
                    raise ValueError("Không tạo được candidate hợp lệ từ Start mù.")
                return cases

            start_state = matrix_to_state(start_mats[0])
            candidates = hidden_completions(goal_mats[0])
            cases = self._pick_candidates(candidates, start_state, start_side=False)
            if not cases:
                raise ValueError("Không tạo được candidate hợp lệ từ Goal mù.")
            return cases

        if env == "Unobservable":
            if blind == "Mù Start":
                if len(start_mats) != 2 or len(goal_mats) != 1:
                    raise ValueError("Unobservable Mù Start cần 2 Start và 1 Goal.")
                goal_state = matrix_to_state(goal_mats[0])
                starts = [matrix_to_state(m) for m in start_mats]
                goals = [goal_state for _ in starts]
                return [GroupProblemCase(starts, goals, "Unobservable Start 1")]

            if len(start_mats) != 1 or len(goal_mats) != 2:
                raise ValueError("Unobservable Mù Goal cần 1 Start và 2 Goal.")
            start_state = matrix_to_state(start_mats[0])
            starts = [start_state for _ in goal_mats]
            goals = [matrix_to_state(m) for m in goal_mats]
            return [GroupProblemCase(starts, goals, "Unobservable Goal 1")]

        raise ValueError("Môi trường không hợp lệ.")

    def _pick_candidates(self, matrices, target_state: State, start_side: bool) -> List[ProblemCase]:
        scored = []
        for idx, m in enumerate(matrices, 1):
            st = matrix_to_state(m)
            if start_side:
                if is_solvable(st) != is_solvable(target_state):
                    continue
                score = state_heuristic(st, target_state)
                scored.append((score, ProblemCase(st, target_state, f"Candidate {idx}")))
            else:
                if is_solvable(target_state) != is_solvable(st):
                    continue
                score = state_heuristic(target_state, st)
                scored.append((score, ProblemCase(target_state, st, f"Candidate {idx}")))

        scored.sort(key=lambda x: x[0])
        return [case for _, case in scored[:2]]
