
from __future__ import annotations

import tkinter as tk

from view import PuzzleView
from controller import AppController

def main():
    root = tk.Tk()
    root.minsize(1500, 900)
    view = PuzzleView(root)
    AppController(root, view)
    root.mainloop()

if __name__ == "__main__":
    main()
