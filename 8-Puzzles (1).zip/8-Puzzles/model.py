
from __future__ import annotations

from dataclasses import dataclass, field
from itertools import permutations
from collections import deque
import math
import random
from typing import List, Tuple, Optional

State = Tuple[int, ...]
Matrix = List[List[int]]

GOAL_STATE: State = (1, 2, 3, 4, 5, 6, 7, 8, 0)
MOVES = {
    "UP": -3,
    "DOWN": 3,
    "LEFT": -1,
    "RIGHT": 1,
}

PAIR_DELIM = "__PAIR_DELIM__"


@dataclass
class SearchResult:
    success: bool
    message: str
    path: List[State] = field(default_factory=list)
    moves: List[str] = field(default_factory=list)
    frontier_log: List[str] = field(default_factory=list)
    reached_log: List[str] = field(default_factory=list)
    current_state_trace: List[State] = field(default_factory=list)
    current_costs: List[dict] = field(default_factory=list)
    explored: int = 0

    @property
    def steps(self) -> int:
        return max(0, len(self.path) - 1)


def state_to_matrix(state: State) -> Matrix:
    return [list(state[i:i + 3]) for i in range(0, 9, 3)]


def matrix_to_state(matrix: Matrix) -> State:
    flat = [int(v) for row in matrix for v in row]
    if len(flat) != 9:
        raise ValueError("Matrix must have exactly 9 values.")
    return tuple(flat)


def format_matrix_text(matrix: Matrix, hidden_as_negative_one: bool = True) -> str:
    rows = []
    for row in matrix:
        rows.append(" ".join(f"{v:>2}" if v != -1 else " -1" for v in row))
    return "\n".join(rows)


def format_state_text(state: State) -> str:
    matrix = state_to_matrix(state)
    rows = []
    for row in matrix:
        rows.append(" ".join(f"{v:>2}" if v != 0 else " 0" for v in row))
    return "\n".join(rows)


def format_cost_line(state: State, g: Optional[int] = None, h: Optional[int] = None,
                     f: Optional[int] = None, t: Optional[float] = None,
                     accepted: Optional[bool] = None) -> str:
    parts = []
    if g is not None:
        parts.append(f"g={g}")
    if h is not None:
        parts.append(f"h={h}")
    if f is not None:
        parts.append(f"f={f}")
    if t is not None:
        parts.append(f"T={t:.2f}")
    if accepted is not None:
        parts.append(f"accept={accepted}")
    prefix = " | ".join(parts)
    body = format_state_text(state)
    return (prefix + "\n" if prefix else "") + body


def parse_numbers_from_line(line: str) -> List[int]:
    line = line.replace("[", " ").replace("]", " ").replace(",", " ")
    nums = []
    for token in line.split():
        try:
            nums.append(int(token))
        except ValueError:
            continue
    return nums


def parse_matrices(text: str) -> List[Matrix]:
    if not text or not text.strip():
        raise ValueError("Empty input.")

    cleaned = text.strip()
    cleaned = cleaned.replace("{", "").replace("}", "")
    cleaned = cleaned.replace("(", "").replace(")", "")

    blocks = []
    raw_blocks = []
    for chunk in cleaned.replace("-----", "\n\n---\n\n").split("\n\n"):
        chunk = chunk.strip()
        if not chunk or chunk == "---":
            continue
        raw_blocks.append(chunk)
    if len(raw_blocks) == 1:
        lines = [ln.strip() for ln in raw_blocks[0].splitlines() if ln.strip()]
        if len(lines) == 6:
            raw_blocks = ["\n".join(lines[:3]), "\n".join(lines[3:])]
        elif len(lines) == 9:
            raw_blocks = ["\n".join(lines)]

    matrices: List[Matrix] = []
    for block in raw_blocks:
        lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
        if len(lines) != 3:
            nums = []
            for ln in lines:
                nums.extend(parse_numbers_from_line(ln))
            if len(nums) == 9:
                matrices.append([nums[:3], nums[3:6], nums[6:9]])
                continue
            raise ValueError("Each matrix must have 3 rows.")
        matrix = []
        for ln in lines:
            nums = parse_numbers_from_line(ln)
            if len(nums) != 3:
                raise ValueError("Each matrix row must have 3 numbers.")
            matrix.append(nums)
        matrices.append(matrix)

    if not matrices:
        raise ValueError("No matrix found.")

    for m in matrices:
        validate_matrix_shape(m)

    return matrices


def validate_matrix_shape(matrix: Matrix) -> None:
    if len(matrix) != 3 or any(len(row) != 3 for row in matrix):
        raise ValueError("Matrix must be 3x3.")


def validate_state(state: State, allow_hidden: bool = False) -> None:
    if len(state) != 9:
        raise ValueError("State must contain 9 cells.")
    values = list(state)
    if allow_hidden:
        allowed = set(range(-1, 9))
    else:
        allowed = set(range(9))
    if any(v not in allowed for v in values):
        raise ValueError("State contains invalid values.")
    # If no hidden cells, check exact permutation.
    if not allow_hidden and sorted(values) != list(range(9)):
        raise ValueError("State must be a permutation of 0..8.")
    if allow_hidden:
        known = [v for v in values if v != -1]
        if len(set(known)) != len(known):
            raise ValueError("Known values must not repeat.")


def is_solvable(state: State) -> bool:
    arr = [v for v in state if v != 0]
    inv = 0
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            if arr[i] > arr[j]:
                inv += 1
    return inv % 2 == 0


def hidden_completions(matrix: Matrix, cap: int = 720) -> List[Matrix]:
    validate_matrix_shape(matrix)
    flat = [v for row in matrix for v in row]
    hidden_idx = [i for i, v in enumerate(flat) if v == -1]
    if not hidden_idx:
        return [matrix]

    known = [v for v in flat if v != -1]
    if len(set(known)) != len(known):
        raise ValueError("Known values repeat; cannot complete matrix.")
    missing = [v for v in range(9) if v not in known]
    if len(missing) != len(hidden_idx):
        raise ValueError("Hidden cells do not match missing tile count.")

    completions = []
    for perm in permutations(missing):
        candidate = list(flat)
        for idx, value in zip(hidden_idx, perm):
            candidate[idx] = value
        completions.append([candidate[0:3], candidate[3:6], candidate[6:9]])
        if len(completions) >= cap:
            break
    return completions


def state_heuristic(state: State, goal: State = GOAL_STATE) -> int:
    pos = {goal[i]: i for i in range(9)}
    dist = 0
    for idx, value in enumerate(state):
        if value == 0:
            continue
        g_idx = pos[value]
        r1, c1 = divmod(idx, 3)
        r2, c2 = divmod(g_idx, 3)
        dist += abs(r1 - r2) + abs(c1 - c2)
    return dist


def misplaced_tiles(state: State, goal: State = GOAL_STATE) -> int:
    return sum(1 for i, v in enumerate(state) if v != 0 and v != goal[i])


def get_blank_index(state: State) -> int:
    return state.index(0)


def neighbors(state: State):
    blank = get_blank_index(state)
    r, c = divmod(blank, 3)
    res = []
    if r > 0:
        n = blank - 3
        arr = list(state)
        arr[blank], arr[n] = arr[n], arr[blank]
        res.append(("UP", tuple(arr)))
    if r < 2:
        n = blank + 3
        arr = list(state)
        arr[blank], arr[n] = arr[n], arr[blank]
        res.append(("DOWN", tuple(arr)))
    if c > 0:
        n = blank - 1
        arr = list(state)
        arr[blank], arr[n] = arr[n], arr[blank]
        res.append(("LEFT", tuple(arr)))
    if c < 2:
        n = blank + 1
        arr = list(state)
        arr[blank], arr[n] = arr[n], arr[blank]
        res.append(("RIGHT", tuple(arr)))
    return res


def bfs(start: State, goal: State) -> SearchResult:
    validate_state(start)
    validate_state(goal)
    if start == goal:
        return SearchResult(True, "Start is already the goal.", [start], [], [], [start], [{"state": start, "g": 0, "h": 0, "f": 0}], 1)

    frontier = deque([start])
    parent = {start: None}
    move_to = {start: None}
    reached = {start}
    frontier_log = []
    reached_log = []
    explored = 0
    current_trace = []
    current_costs = []

    while frontier:
        frontier_log.append(_frontier_text(list(frontier), mode="bfs"))
        reached_log.append(_frontier_text(list(reached), mode="bfs_reached"))
        current = frontier.popleft()
        explored += 1
        current_trace.append(current)
        current_costs.append({"state": current, "g": _depth(parent, current), "h": 0, "f": _depth(parent, current)})

        if current == goal:
            path, moves = _reconstruct(parent, move_to, current)
            return SearchResult(True, "Goal found.", path, moves, frontier_log, reached_log, current_trace, current_costs, explored)

        for move, nxt in neighbors(current):
            if nxt not in reached:
                reached.add(nxt)
                parent[nxt] = current
                move_to[nxt] = move
                frontier.append(nxt)

    return SearchResult(False, "No solution found.", [], [], frontier_log, reached_log, current_trace, current_costs, explored)


def simulated_annealing(start: State, goal: State, max_steps: int = 4000,
                        initial_temp: float = 25.0, alpha: float = 0.995,
                        seed: Optional[int] = None) -> SearchResult:
    validate_state(start)
    validate_state(goal)
    rng = random.Random(seed)
    current = start
    path = [current]
    moves: List[str] = []
    frontier_log: List[str] = []
    reached_log: List[str] = []
    trace = [current]
    costs = [{"state": current, "g": 0, "h": state_heuristic(current, goal), "f": state_heuristic(current, goal), "temperature": initial_temp, "accepted": True}]
    explored = 1
    temperature = initial_temp

    best = current
    best_h = state_heuristic(current, goal)

    if current == goal:
        return SearchResult(True, "Start is already the goal.", path, moves, frontier_log, reached_log, trace, costs, explored)

    for step in range(max_steps):
        h_current = state_heuristic(current, goal)
        if h_current < best_h:
            best = current
            best_h = h_current

        if current == goal:
            return SearchResult(True, "Goal found.", path, moves, frontier_log, reached_log, trace, costs, explored)

        neigh = neighbors(current)
        if not neigh:
            break

        frontier_log.append(_frontier_text([n for _, n in neigh], mode="sa_frontier", goal=goal))
        reached_log.append(_frontier_text(path[-10:], mode="sa_reached", goal=goal))

        move, nxt = rng.choice(neigh)
        h_next = state_heuristic(nxt, goal)
        delta = h_next - h_current

        if delta <= 0:
            accept = True
        else:
            prob = math.exp(-delta / max(temperature, 1e-9))
            accept = rng.random() < prob

        if accept:
            current = nxt
            path.append(current)
            moves.append(move)
            trace.append(current)
            costs.append({"state": current, "g": len(path)-1, "h": h_next, "f": h_next, "temperature": temperature, "accepted": True})
            explored += 1
            if current == goal:
                return SearchResult(True, "Goal found by simulated annealing.", path, moves, frontier_log, reached_log, trace, costs, explored)
        else:
            costs.append({"state": current, "g": len(path)-1, "h": h_current, "f": h_current, "temperature": temperature, "accepted": False})
            explored += 1

        temperature *= alpha
        if temperature < 1e-6:
            break

    if best == goal:
        return SearchResult(True, "Goal found.", [best], [], frontier_log, reached_log, trace, costs, explored)
    return SearchResult(False, "No solution found within the annealing limit.", path, moves, frontier_log, reached_log, trace, costs, explored)


def _depth(parent, node):
    d = 0
    while parent.get(node) is not None:
        node = parent[node]
        d += 1
    return d


def _reconstruct(parent, move_to, goal):
    path = []
    moves = []
    node = goal
    while node is not None:
        path.append(node)
        m = move_to.get(node)
        if m is not None:
            moves.append(m)
        node = parent[node]
    path.reverse()
    moves.reverse()
    return path, moves


def _frontier_text(items, mode="bfs", goal: Optional[State] = None):
    lines = []
    for i, st in enumerate(items, 1):
        lines.append(f"[{i}]")
        if mode == "bfs_reached":
            lines.append(format_state_text(st))
        elif mode == "sa_frontier":
            h = state_heuristic(st, goal or GOAL_STATE)
            lines.append(f"h={h}\n{format_state_text(st)}")
        elif mode == "sa_reached":
            h = state_heuristic(st, goal or GOAL_STATE)
            lines.append(f"h={h}\n{format_state_text(st)}")
        else:
            lines.append(format_state_text(st))
        lines.append("")
    return "\n".join(lines).strip()


GroupState = Tuple[State, ...]


def apply_move(state: State, move: str) -> Optional[State]:
    """Return the next state after applying a move, or None if invalid."""
    if move not in MOVES:
        raise ValueError(f"Unknown move: {move}")
    blank = get_blank_index(state)
    r, c = divmod(blank, 3)
    target = None
    if move == "UP" and r > 0:
        target = blank - 3
    elif move == "DOWN" and r < 2:
        target = blank + 3
    elif move == "LEFT" and c > 0:
        target = blank - 1
    elif move == "RIGHT" and c < 2:
        target = blank + 1
    if target is None:
        return None
    arr = list(state)
    arr[blank], arr[target] = arr[target], arr[blank]
    return tuple(arr)


def legal_moves(state: State) -> List[str]:
    blank = get_blank_index(state)
    r, c = divmod(blank, 3)
    moves: List[str] = []
    if r > 0:
        moves.append("UP")
    if r < 2:
        moves.append("DOWN")
    if c > 0:
        moves.append("LEFT")
    if c < 2:
        moves.append("RIGHT")
    return moves


def is_group_state(state) -> bool:
    return (
        isinstance(state, tuple)
        and len(state) > 0
        and isinstance(state[0], tuple)
        and len(state[0]) == 9
    )


def group_state_heuristic(group_state: GroupState, goals: GroupState) -> int:
    return sum(state_heuristic(st, goal) for st, goal in zip(group_state, goals))


def group_neighbors(group_state: GroupState, goals: GroupState):
    active_indices = [i for i, (st, goal) in enumerate(zip(group_state, goals)) if st != goal]
    if not active_indices:
        return []

    common: Optional[set[str]] = None
    for i in active_indices:
        moves = set(legal_moves(group_state[i]))
        common = moves if common is None else common & moves
        if not common:
            return []

    ordered = [m for m in ("UP", "DOWN", "LEFT", "RIGHT") if m in common]
    result = []
    for move in ordered:
        nxt_boards = []
        for i, (st, goal) in enumerate(zip(group_state, goals)):
            if st == goal:
                nxt_boards.append(st)
            else:
                nxt = apply_move(st, move)
                if nxt is None:
                    break
                nxt_boards.append(nxt)
        else:
            result.append((move, tuple(nxt_boards)))
    return result


def format_group_state_text(group_state: GroupState) -> str:
    blocks = [format_state_text(st) for st in group_state]
    return "{\n" + ",\n\n".join(blocks) + "\n}"


def _group_frontier_text(items, mode: str = "bfs", goals: Optional[GroupState] = None):
    blocks = []
    for st in items:
        if mode == "sa_frontier":
            h = group_state_heuristic(st, goals or tuple([GOAL_STATE] * len(st)))
            blocks.append(f"h={h}\n{format_group_state_text(st)}")
        elif mode == "sa_reached":
            h = group_state_heuristic(st, goals or tuple([GOAL_STATE] * len(st)))
            blocks.append(f"h={h}\n{format_group_state_text(st)}")
        else:
            blocks.append(format_group_state_text(st))
    return "\n\n".join(blocks).strip()


def _group_reconstruct(parent, move_to, goal):
    path = []
    moves = []
    node = goal
    while node is not None:
        path.append(node)
        m = move_to.get(node)
        if m is not None:
            moves.append(m)
        node = parent[node]
    path.reverse()
    moves.reverse()
    return path, moves


def group_bfs(starts: List[State], goals: List[State]) -> SearchResult:
    if not starts or not goals:
        raise ValueError("Group BFS requires at least one start and one goal.")
    if len(starts) != len(goals):
        raise ValueError("Starts and goals must have the same length for grouped search.")

    for st in starts:
        validate_state(st)
    for goal in goals:
        validate_state(goal)

    start = tuple(starts)
    goal_tuple = tuple(goals)

    if start == goal_tuple:
        return SearchResult(True, "Start group is already at the goal group.", [start], [], [], [start], [{"state": start, "g": 0, "h": 0, "f": 0}], 1)

    frontier = deque([start])
    parent = {start: None}
    move_to = {start: None}
    reached = {start}
    frontier_log = []
    reached_log = []
    explored = 0
    current_trace = []
    current_costs = []

    while frontier:
        frontier_log.append(_group_frontier_text(list(frontier), mode="bfs"))
        reached_log.append(_group_frontier_text(list(reached), mode="bfs_reached"))
        current = frontier.popleft()
        explored += 1
        current_trace.append(current)
        h = group_state_heuristic(current, goal_tuple)
        current_costs.append({"state": current, "g": _depth(parent, current), "h": h, "f": _depth(parent, current) + h})

        if current == goal_tuple:
            path, moves = _group_reconstruct(parent, move_to, current)
            return SearchResult(True, "Goal found for the whole group.", path, moves, frontier_log, reached_log, current_trace, current_costs, explored)

        for move, nxt in group_neighbors(current, goal_tuple):
            if nxt not in reached:
                reached.add(nxt)
                parent[nxt] = current
                move_to[nxt] = move
                frontier.append(nxt)

    return SearchResult(False, "No solution found for the whole group.", [], [], frontier_log, reached_log, current_trace, current_costs, explored)


def group_simulated_annealing(starts: List[State], goals: List[State], max_steps: int = 4000,
                              initial_temp: float = 25.0, alpha: float = 0.995,
                              seed: Optional[int] = None) -> SearchResult:
    if not starts or not goals:
        raise ValueError("Group simulated annealing requires at least one start and one goal.")
    if len(starts) != len(goals):
        raise ValueError("Starts and goals must have the same length for grouped search.")

    for st in starts:
        validate_state(st)
    for goal in goals:
        validate_state(goal)

    rng = random.Random(seed)
    current = tuple(starts)
    goal_tuple = tuple(goals)
    path = [current]
    moves: List[str] = []
    frontier_log: List[str] = []
    reached_log: List[str] = []
    trace = [current]
    h0 = group_state_heuristic(current, goal_tuple)
    costs = [{"state": current, "g": 0, "h": h0, "f": h0, "temperature": initial_temp, "accepted": True}]
    explored = 1
    temperature = initial_temp

    best = current
    best_h = h0

    if current == goal_tuple:
        return SearchResult(True, "Start group is already at the goal group.", path, moves, frontier_log, reached_log, trace, costs, explored)

    for _ in range(max_steps):
        h_current = group_state_heuristic(current, goal_tuple)
        if h_current < best_h:
            best = current
            best_h = h_current

        if current == goal_tuple:
            return SearchResult(True, "Goal found by group simulated annealing.", path, moves, frontier_log, reached_log, trace, costs, explored)

        neigh = group_neighbors(current, goal_tuple)
        if not neigh:
            break

        frontier_log.append(_group_frontier_text([n for _, n in neigh], mode="sa_frontier", goals=goal_tuple))
        reached_log.append(_group_frontier_text(path[-10:], mode="sa_reached", goals=goal_tuple))

        move, nxt = rng.choice(neigh)
        h_next = group_state_heuristic(nxt, goal_tuple)
        delta = h_next - h_current

        if delta <= 0:
            accept = True
        else:
            prob = math.exp(-delta / max(temperature, 1e-9))
            accept = rng.random() < prob

        if accept:
            current = nxt
            path.append(current)
            moves.append(move)
            trace.append(current)
            costs.append({"state": current, "g": len(path) - 1, "h": h_next, "f": h_next, "temperature": temperature, "accepted": True})
            explored += 1
            if current == goal_tuple:
                return SearchResult(True, "Goal found by group simulated annealing.", path, moves, frontier_log, reached_log, trace, costs, explored)
        else:
            costs.append({"state": current, "g": len(path) - 1, "h": h_current, "f": h_current, "temperature": temperature, "accepted": False})
            explored += 1

        temperature *= alpha
        if temperature < 1e-6:
            break

    if best == goal_tuple:
        return SearchResult(True, "Goal found.", [best], [], frontier_log, reached_log, trace, costs, explored)
    return SearchResult(False, "No solution found within the annealing limit.", path, moves, frontier_log, reached_log, trace, costs, explored)
