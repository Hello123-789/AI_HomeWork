from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Callable, Iterable, Optional

from model import GOAL_STATE


class PuzzleView:
    BG = "#f5f7ff"
    CARD = "#ffffff"
    CARD_2 = "#f8fbff"
    ACCENT = "#4f6ef7"
    ACCENT_DARK = "#3d57d8"
    TEXT = "#1f2937"
    MUTED = "#667085"
    BORDER = "#d7def0"
    CELL = "#ffffff"
    CELL_HIDDEN = "#d1d5db"
    CELL_EMPTY = "#e7edf8"

    def __init__(self, root):
        self.root = root
        self.root.title("8 Puzzle Explorer")
        self.root.geometry("1760x960")
        self.root.minsize(1480, 840)
        try:
            self.root.state("zoomed")
        except tk.TclError:
            pass
        self.root.configure(bg=self.BG)

        self._mode_change_cb: Optional[Callable[[], None]] = None
        self._case_change_cb: Optional[Callable[[], None]] = None

        self._setup_style()
        self._build_ui()
        self._wire_events()

    def _setup_style(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", background=self.BG, foreground=self.TEXT, font=("Segoe UI", 10))
        style.configure("App.TFrame", background=self.BG)
        style.configure("Card.TFrame", background=self.CARD)
        style.configure("Title.TLabel", background=self.BG, foreground=self.ACCENT, font=("Segoe UI", 20, "bold"))
        style.configure("Sub.TLabel", background=self.BG, foreground=self.MUTED, font=("Segoe UI", 10))
        style.configure("Section.TLabel", background=self.CARD, foreground=self.TEXT, font=("Segoe UI", 12, "bold"))
        style.configure("Accent.TButton", background=self.ACCENT, foreground="white", padding=(16, 9), borderwidth=0)
        style.configure("Soft.TButton", background="#e9eefc", foreground=self.TEXT, padding=(16, 9), borderwidth=0)
        style.map("Accent.TButton", background=[("active", self.ACCENT_DARK)])
        style.map("Soft.TButton", background=[("active", "#dbe6ff"), ("pressed", "#dbe6ff")])
        style.configure("TCombobox", padding=6)

    def _build_ui(self):
        main = ttk.Frame(self.root, style="App.TFrame", padding=10)
        main.pack(fill="both", expand=True)
        main.grid_columnconfigure(0, weight=0)
        main.grid_columnconfigure(1, weight=1)
        main.grid_rowconfigure(0, weight=1)

        # Left log panel
        left = ttk.Frame(main, style="Card.TFrame", width=390)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 10))
        left.grid_propagate(False)
        left.grid_columnconfigure(0, weight=1)
        left.grid_rowconfigure(1, weight=1)
        left.grid_rowconfigure(3, weight=1)

        ttk.Label(left, text="Frontier", style="Section.TLabel").grid(row=0, column=0, sticky="w", padx=14, pady=(12, 6))
        self.frontier_text = self._create_text_box(left, height=12, width=38, monospace=True)
        self.frontier_text.grid(row=1, column=0, sticky="nsew", padx=14, pady=(0, 10))

        ttk.Label(left, text="Reached", style="Section.TLabel").grid(row=2, column=0, sticky="w", padx=14, pady=(6, 6))
        self.reached_text = self._create_text_box(left, height=12, width=38, monospace=True)
        self.reached_text.grid(row=3, column=0, sticky="nsew", padx=14, pady=(0, 14))

        # Scrollable workspace
        workspace = ttk.Frame(main, style="App.TFrame")
        workspace.grid(row=0, column=1, sticky="nsew")
        workspace.grid_columnconfigure(0, weight=1)
        workspace.grid_rowconfigure(0, weight=1)

        self.work_canvas = tk.Canvas(workspace, bg=self.BG, highlightthickness=0)
        vsb = ttk.Scrollbar(workspace, orient="vertical", command=self.work_canvas.yview)
        hsb = ttk.Scrollbar(workspace, orient="horizontal", command=self.work_canvas.xview)
        self.work_canvas.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.work_canvas.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        self.work_inner = ttk.Frame(self.work_canvas, style="App.TFrame")
        self.work_window = self.work_canvas.create_window((0, 0), window=self.work_inner, anchor="nw")
        self.work_inner.bind("<Configure>", self._on_work_inner_configure)
        self.work_canvas.bind("<Configure>", self._on_work_canvas_configure)
        self.work_canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self.work_canvas.bind_all("<Shift-MouseWheel>", self._on_shift_mousewheel)
        self.work_canvas.bind_all("<Button-4>", self._on_mousewheel_linux)
        self.work_canvas.bind_all("<Button-5>", self._on_mousewheel_linux)

        content = self.work_inner
        content.grid_columnconfigure(0, weight=1)

        header = ttk.Frame(content, style="App.TFrame")
        header.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(header, text="8 Puzzle Explorer", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Nhập trạng thái rồi chọn chế độ để chạy BFS hoặc Simulated Annealing.",
            style="Sub.TLabel",
        ).pack(anchor="w", pady=(3, 0))

        # Sample-like top layout: start / control / goal
        top = ttk.Frame(content, style="Card.TFrame")
        top.grid(row=1, column=0, sticky="ew")
        top.grid_columnconfigure(0, weight=1)
        top.grid_columnconfigure(1, weight=1)
        top.grid_columnconfigure(2, weight=1)

        start_card = ttk.Frame(top, style="Card.TFrame")
        start_card.grid(row=0, column=0, sticky="nsew", padx=(12, 8), pady=12)
        ttk.Label(start_card, text="Input trạng thái start", style="Section.TLabel").pack(anchor="w", pady=(0, 6))
        self.start_text = self._create_text_box(start_card, height=10, width=30, monospace=True)
        self.start_text.pack(fill="both", expand=True)

        control_card = ttk.Frame(top, style="Card.TFrame")
        control_card.grid(row=0, column=1, sticky="nsew", padx=8, pady=12)
        ttk.Label(control_card, text="Chọn thuật toán", style="Section.TLabel").pack(anchor="w", pady=(0, 6))

        self.algo_var = tk.StringVar(value="BFS")
        self.algo_combo = ttk.Combobox(
            control_card,
            textvariable=self.algo_var,
            state="readonly",
            values=["BFS", "SIMULATED ANNEALING"],
        )
        self.algo_combo.pack(fill="x")

        self.algo_help = tk.Text(
            control_card,
            height=7,
            wrap="word",
            bg=self.CARD_2,
            fg=self.MUTED,
            relief="flat",
            highlightthickness=1,
            highlightbackground=self.BORDER,
            padx=8,
            pady=8,
        )
        self.algo_help.pack(fill="both", expand=True, pady=(8, 0))
        self.algo_help.insert(
            "1.0",
            "BFS: tìm lời giải ngắn nhất.\n"
            "Simulated Annealing: tìm kiếm ngẫu nhiên theo nhiệt độ.\n"
            "Observable: nhập 2 ma trận trong Start và 2 ma trận trong Goal.\n"
            "Partially Observable: dùng -1 cho ô bị khuất.\n"
            "Unobservable: 2 Start hoặc 2 Goal, giải riêng từng bài toán.",
        )
        self.algo_help.configure(state="disabled")

        env_row = ttk.Frame(control_card, style="Card.TFrame")
        env_row.pack(fill="x", pady=(8, 0))
        ttk.Label(env_row, text="Môi trường", style="Section.TLabel").grid(row=0, column=0, sticky="w")
        self.env_var = tk.StringVar(value="Observable")
        self.env_combo = ttk.Combobox(
            env_row,
            textvariable=self.env_var,
            state="readonly",
            values=["Observable", "Partially Observable", "Unobservable"],
            width=19,
        )
        self.env_combo.grid(row=0, column=1, sticky="w", padx=(10, 0))

        ttk.Label(env_row, text="Loại mù", style="Section.TLabel").grid(row=1, column=0, sticky="w", pady=(10, 0))
        self.blind_var = tk.StringVar(value="Mù Start")
        self.blind_combo = ttk.Combobox(
            env_row,
            textvariable=self.blind_var,
            state="readonly",
            values=["Mù Start", "Mù Goal"],
            width=19,
        )
        self.blind_combo.grid(row=1, column=1, sticky="w", padx=(10, 0), pady=(10, 0))

        ttk.Label(env_row, text="Mẫu mù", style="Section.TLabel").grid(row=2, column=0, sticky="w", pady=(10, 0))
        ttk.Label(env_row, text="Tự cập nhật theo môi trường", style="Sub.TLabel").grid(row=2, column=1, sticky="w", padx=(10, 0), pady=(10, 0))

        goal_card = ttk.Frame(top, style="Card.TFrame")
        goal_card.grid(row=0, column=2, sticky="nsew", padx=(8, 12), pady=12)
        ttk.Label(goal_card, text="Input trạng thái goal", style="Section.TLabel").pack(anchor="w", pady=(0, 6))
        self.goal_text = self._create_text_box(goal_card, height=10, width=30, monospace=True)
        self.goal_text.pack(fill="both", expand=True)

        # Controls like the sample
        btn_row = ttk.Frame(content, style="App.TFrame")
        btn_row.grid(row=2, column=0, sticky="w", pady=(8, 4))
        self.solve_btn = ttk.Button(btn_row, text="Solve", style="Accent.TButton")
        self.prev_btn = ttk.Button(btn_row, text="Prev", style="Soft.TButton")
        self.next_btn = ttk.Button(btn_row, text="Next", style="Soft.TButton")
        self.solve_btn.pack(side="left", padx=(0, 10))
        self.prev_btn.pack(side="left", padx=10)
        self.next_btn.pack(side="left", padx=10)

        self.status_label = ttk.Label(content, text="Sẵn sàng.", style="Sub.TLabel")
        self.status_label.grid(row=3, column=0, sticky="w", pady=(0, 2))
        self.step_label = ttk.Label(content, text="Bước: 0/0", style="Sub.TLabel")
        self.step_label.grid(row=4, column=0, sticky="w", pady=(0, 6))

        board_card = ttk.Frame(content, style="Card.TFrame")
        board_card.grid(row=5, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(board_card, text="Ma trận hiện tại", style="Section.TLabel").pack(anchor="w", padx=12, pady=(10, 6))
        self.board_canvas = tk.Canvas(board_card, width=700, height=260, bg=self.CARD, highlightthickness=0)
        self.board_canvas.pack(padx=12, pady=(0, 10), anchor="w")

        bottom = ttk.Frame(content, style="App.TFrame")
        bottom.grid(row=6, column=0, sticky="nsew")
        bottom.grid_columnconfigure(0, weight=1)

        tree_card = ttk.Frame(bottom, style="Card.TFrame")
        tree_card.grid(row=0, column=0, sticky="nsew")
        tree_card.grid_columnconfigure(0, weight=1)
        ttk.Label(tree_card, text="Cây ma trận lời giải", style="Section.TLabel").pack(anchor="w", padx=12, pady=(10, 4))

        tree_wrap = ttk.Frame(tree_card, style="Card.TFrame")
        tree_wrap.pack(fill="both", expand=True, padx=12, pady=(0, 10))
        tree_wrap.grid_columnconfigure(0, weight=1)
        tree_wrap.grid_rowconfigure(0, weight=1)

        self.tree_canvas = tk.Canvas(tree_wrap, width=420, height=260, bg=self.CARD, highlightthickness=0)
        self.tree_canvas.grid(row=0, column=0, sticky="nsew")
        tree_y = ttk.Scrollbar(tree_wrap, orient="vertical", command=self.tree_canvas.yview)
        tree_x = ttk.Scrollbar(tree_wrap, orient="horizontal", command=self.tree_canvas.xview)
        tree_y.grid(row=0, column=1, sticky="ns")
        tree_x.grid(row=1, column=0, sticky="ew")
        self.tree_canvas.configure(yscrollcommand=tree_y.set, xscrollcommand=tree_x.set)

        self._load_default_texts()

    def _on_work_inner_configure(self, event=None):
        self.work_canvas.configure(scrollregion=self.work_canvas.bbox("all"))

    def _on_mousewheel(self, event):
        if event.state & 0x1:
            self.work_canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")
        else:
            self.work_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _on_shift_mousewheel(self, event):
        self.work_canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")

    def _on_mousewheel_linux(self, event):
        delta = -1 if getattr(event, "num", None) == 5 else 1
        self.work_canvas.yview_scroll(delta, "units")

    def _on_work_canvas_configure(self, event=None):
        self.work_canvas.itemconfigure(self.work_window, width=event.width)

    def _create_text_box(self, parent, height=10, width=30, monospace=False):
        font = ("Consolas", 12) if monospace else ("Segoe UI", 10)
        wrap = "none" if monospace else "word"
        frame = ttk.Frame(parent, style="Card.TFrame")
        txt = tk.Text(
            frame,
            height=height,
            width=width,
            wrap=wrap,
            bg=self.CARD_2,
            fg=self.TEXT,
            font=font,
            relief="flat",
            highlightthickness=1,
            highlightbackground=self.BORDER,
            padx=8,
            pady=8,
        )
        y = ttk.Scrollbar(frame, orient="vertical", command=txt.yview)
        x = ttk.Scrollbar(frame, orient="horizontal", command=txt.xview)
        txt.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        txt.grid(row=0, column=0, sticky="nsew")
        y.grid(row=0, column=1, sticky="ns")
        x.grid(row=1, column=0, sticky="ew")
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(0, weight=1)
        frame.text_widget = txt
        return frame

    def _wire_events(self):
        self.env_combo.bind("<<ComboboxSelected>>", self._on_mode_changed)
        self.blind_combo.bind("<<ComboboxSelected>>", self._on_mode_changed)

    def set_mode_change_callback(self, callback: Callable[[], None]):
        self._mode_change_cb = callback

    def set_callbacks(self, solve_cb, prev_cb, next_cb):
        self.solve_btn.configure(command=solve_cb)
        self.prev_btn.configure(command=prev_cb)
        self.next_btn.configure(command=next_cb)

    def refresh_mode_labels(self):
        self._on_mode_changed()

    def _on_mode_changed(self, event=None):
        if self._mode_change_cb:
            self._mode_change_cb()

    def get_start_raw(self) -> str:
        return self.start_text.text_widget.get("1.0", tk.END).strip()

    def get_goal_raw(self) -> str:
        return self.goal_text.text_widget.get("1.0", tk.END).strip()


    def show_result_summary(self, text: str):
        pass

    def set_frontier_text(self, text: str):
        txt = self.frontier_text.text_widget
        txt.configure(state="normal")
        txt.delete("1.0", tk.END)
        txt.insert("1.0", text)
        txt.configure(state="disabled")

    def set_reached_text(self, text: str):
        txt = self.reached_text.text_widget
        txt.configure(state="normal")
        txt.delete("1.0", tk.END)
        txt.insert("1.0", text)
        txt.configure(state="disabled")

    def set_status(self, text: str):
        self.status_label.config(text=text)

    def set_step(self, current: int, total: int):
        self.step_label.config(text=f"Bước: {current}/{total}")

    def _looks_like_single_state(self, state) -> bool:
        return isinstance(state, (list, tuple)) and len(state) == 9 and all(isinstance(v, int) for v in state)

    def _looks_like_group_state(self, state) -> bool:
        return isinstance(state, (list, tuple)) and len(state) > 0 and not self._looks_like_single_state(state)

    def draw_board(self, state):
        self.board_canvas.delete("all")

        if self._looks_like_group_state(state):
            boards = list(state)
            cell = 42
            board_size = cell * 3
            gap_x = 28
            gap_y = 30
            boards_per_row = 2

            for idx, board in enumerate(boards):
                row = idx // boards_per_row
                col = idx % boards_per_row
                x0 = 16 + col * (board_size + gap_x)
                y0 = 28 + row * (board_size + gap_y)
                self.board_canvas.create_text(
                    x0, y0 - 14,
                    anchor="nw", text=f"Matrix {idx + 1}",
                    font=("Segoe UI", 10, "bold"), fill=self.ACCENT,
                )
                self._draw_board_grid(self.board_canvas, board, x0, y0, cell=cell, label_size=22)
            return

        self._draw_board_grid(self.board_canvas, state, 12, 10, cell=66, label_size=22)

    def _draw_board_grid(self, canvas, state, x0, y0, cell=66, label_size=22):
        for i, value in enumerate(state):
            r, c = divmod(i, 3)
            x1 = x0 + c * cell
            y1 = y0 + r * cell
            x2 = x1 + cell
            y2 = y1 + cell
            if value == 0:
                fill, text = self.CELL_EMPTY, ""
            elif value == -1:
                fill, text = self.CELL_HIDDEN, "-1"
            else:
                fill, text = self.CELL, str(value)
            canvas.create_rectangle(x1, y1, x2, y2, fill=fill, outline=self.BORDER, width=2)
            if text:
                canvas.create_text(
                    (x1 + x2) / 2, (y1 + y2) / 2,
                    text=text, font=("Arial", label_size, "bold"), fill=self.TEXT,
                )

    def draw_solution_path(self, result, title: str = "", max_width: int = 370):
        self.draw_solution_forest([result], [title] if title else None)

    def draw_solution_forest(self, results, titles=None):
        self.tree_canvas.delete("all")
        if not results:
            self.tree_canvas.create_text(
                20, 20, anchor="nw", text="Không có dữ liệu để hiển thị.",
                fill=self.MUTED, font=("Segoe UI", 10)
            )
            self.tree_canvas.configure(scrollregion=(0, 0, 420, 260))
            return

        canvas = self.tree_canvas
        x = 150
        y = 16
        block_gap_y = 44
        titles = list(titles) if titles is not None else []

        for ridx, result in enumerate(results):
            label = titles[ridx] if ridx < len(titles) and titles[ridx] else f"Lời giải {ridx + 1}"
            canvas.create_text(
                x+180, y-60, anchor="nw", text=label,
                font=("Segoe UI", 12, "bold"), fill=self.ACCENT,
            )
            y += 22
            if not result or not getattr(result, "path", None):
                canvas.create_text(
                    x, y, anchor="nw", text="Không có dữ liệu để hiển thị.",
                    fill=self.MUTED, font=("Segoe UI", 10)
                )
                y += 30
                continue

            first_state = result.path[0]
            if self._looks_like_group_state(first_state) and len(first_state) >= 2:
                used = self._draw_dual_solution_tree(canvas, x, y, result.path, result.moves)
            else:
                used = self._draw_single_solution_tree(canvas, x, y, result.path, result.moves)

            y += used + block_gap_y

        canvas.configure(scrollregion=canvas.bbox("all") or (0, 0, 420, max(260, y)))

    def _draw_single_solution_tree(self, canvas, x, y, path, moves):
        board_size = 22 * 3
        step_gap = 122
        for idx, state in enumerate(path):
            self._draw_small_board(canvas, x, y + idx * step_gap, state, size=22)
            canvas.create_text(
                x + board_size + 18, y + idx * step_gap + 18,
                text=f"Bước {idx}", anchor="w",
                font=("Segoe UI", 10, "bold"), fill=self.ACCENT,
            )
            if idx < len(moves):
                canvas.create_line(
                    x + board_size // 2, y + idx * step_gap + board_size + 4,
                    x + board_size // 2, y + (idx + 1) * step_gap - 10,
                    arrow=tk.LAST, width=2, fill=self.ACCENT,
                )
                canvas.create_text(
                    x + board_size + 18, y + idx * step_gap + 42,
                    text=moves[idx], anchor="w",
                    font=("Segoe UI", 9, "bold"), fill=self.ACCENT_DARK,
                )
        return max(1, len(path)) * step_gap

    def _draw_dual_solution_tree(self, canvas, x, y, path, moves):
        board_size = 22 * 3
        col_gap = 60
        step_gap = 126
        left_x = x
        right_x = x + board_size + col_gap

        canvas.create_text(left_x, y - 15, anchor="nw", text="Cây 1", font=("Segoe UI", 10, "bold"), fill=self.ACCENT)
        canvas.create_text(right_x, y - 15, anchor="nw", text="Cây 2", font=("Segoe UI", 10, "bold"), fill=self.ACCENT)

        for idx, state in enumerate(path):
            if len(state) >= 2:
                left_board, right_board = state[0], state[1]
            else:
                left_board = right_board = state[0] if state else state

            y0 = y + idx * step_gap
            self._draw_small_board(canvas, left_x, y0, left_board, size=22)
            self._draw_small_board(canvas, right_x, y0, right_board, size=22)

            canvas.create_text(
                x + 2 * board_size + col_gap + 20, y0 + 18,
                text=f"Bước {idx}", anchor="w",
                font=("Segoe UI", 10, "bold"), fill=self.ACCENT,
            )
            if idx < len(moves):
                canvas.create_text(
                    x + 2 * board_size + col_gap + 20, y0 + 42,
                    text=moves[idx], anchor="w",
                    font=("Segoe UI", 9, "bold"), fill=self.ACCENT_DARK,
                )
                for bx in (left_x, right_x):
                    canvas.create_line(
                        bx + board_size // 2, y0 + board_size + 4,
                        bx + board_size // 2, y0 + step_gap - 12,
                        arrow=tk.LAST, width=2, fill=self.ACCENT,
                    )
        return max(1, len(path)) * step_gap

    def _draw_small_group(self, canvas, x, y, group_state):
        board_size = 22 * 3
        gap_x = 22
        boards_per_row = 2
        for idx, board in enumerate(group_state):
            row = idx // boards_per_row
            col = idx % boards_per_row
            bx = x + col * (board_size + gap_x)
            by = y + row * (board_size + 24)
            canvas.create_text(bx, by - 12, anchor="nw", text=f"M{idx + 1}", font=("Segoe UI", 8, "bold"), fill=self.ACCENT)
            self._draw_small_board(canvas, bx, by, board, size=22)

    def _draw_small_board(self, canvas, x, y, state, size=24):
        for i, value in enumerate(state):
            r, c = divmod(i, 3)
            x1 = x + c * size
            y1 = y + r * size
            x2 = x1 + size
            y2 = y1 + size
            if value == 0:
                fill, text = self.CELL_EMPTY, ""
            elif value == -1:
                fill, text = self.CELL_HIDDEN, "-1"
            else:
                fill, text = self.CELL, str(value)
            canvas.create_rectangle(x1, y1, x2, y2, fill=fill, outline=self.BORDER, width=1)
            if text:
                canvas.create_text((x1 + x2) / 2, (y1 + y2) / 2, text=text, font=("Arial", 8, "bold"), fill=self.TEXT)

    def _load_default_texts(self):
        start_default = "{\n1 2 3\n4 0 5\n7 8 6\n\n1 2 3\n4 5 6\n7 0 8\n}"
        goal_default = "{\n1 2 3\n4 5 6\n7 8 0\n\n1 2 3\n4 0 5\n7 8 6\n}"
        self.start_text.text_widget.delete("1.0", tk.END)
        self.start_text.text_widget.insert("1.0", start_default)
        self.goal_text.text_widget.delete("1.0", tk.END)
        self.goal_text.text_widget.insert("1.0", goal_default)

    def set_status_text(self, text: str):
        self.set_status(text)
