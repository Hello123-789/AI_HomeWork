8 Puzzle Solver

BFS / DFS / IDS / UCS / GREEDY / A* / IDA* / HILL CLIMBING / BEST HILL CLIMBING / STOCHASTIC HILL CLIMBING / RANDOM RESTART HILL CLIMBING/Local Beam Search

Giới thiệu

Đây là chương trình giải bài toán 8-Puzzle bằng nhiều thuật toán tìm kiếm và tìm kiếm heuristic, bao gồm:

BFS (Breadth-First Search)
DFS (Depth-First Search)
IDS (Iterative Deepening Search)
UCS (Uniform Cost Search)
Greedy Search
A*
IDA*
Hill Climbing
Best Hill Climbing (Steepest-Ascent Hill Climbing)
STOCHASTIC HILL CLIMBING
RANDOM RESTART HILL CLIMBING
Local Beam Search

Người dùng nhập trạng thái Start và Goal trực tiếp trên giao diện đồ họa (GUI), sau đó lựa chọn thuật toán cần thực hiện để quan sát quá trình tìm kiếm và lời giải.

Cấu trúc Project

main.py: Khởi chạy chương trình.
model.py: Chứa các thuật toán giải bài toán.
view.py: Xây dựng giao diện người dùng.
controller.py: Kết nối giữa Model và View.

Chức năng chính

Nhập trạng thái Start và Goal.
Kiểm tra tính hợp lệ của dữ liệu đầu vào.
Kiểm tra Puzzle có thể giải được hay không.
Chọn thuật toán tìm kiếm.
Hiển thị đường đi lời giải.
Hiển thị số bước thực hiện.
Hiển thị thời gian chạy.
Hiển thị các trạng thái được duyệt trong quá trình tìm kiếm.

Đối với các thuật toán BFS, DFS, IDS, UCS, Greedy, A* và IDA*, chương trình hiển thị Frontier và Reached cùng các trạng thái đang được xét.

Đối với Hill Climbing và Best Hill Climbing, chương trình hiển thị Current State và Next State kèm theo giá trị heuristic của từng trạng thái.

Đối với Stochastic Hill Climbing và Random Restart Hill Climbing, chương trình hiển thị Current State, Next State và Better Neighbors. Hai thuật toán này sử dụng heuristic Manhattan.

Biểu diễn trạng thái

Mỗi trạng thái được lưu dưới dạng một tuple gồm 9 phần tử tương ứng với ma trận 3x3. Số 0 đại diện cho ô trống.

Ví dụ trạng thái đích:

1 2 3

4 5 6

7 8 0

Quy ước sinh node

Các trạng thái con được sinh theo thứ tự:

Left → Right → Up → Down

Tất cả các thuật toán trong chương trình đều sử dụng chung quy tắc sinh node này.

Các thuật toán

BFS (Breadth-First Search)

BFS sử dụng hàng đợi FIFO (First In First Out). Thuật toán mở rộng các trạng thái theo từng mức độ sâu và luôn tìm được lời giải ngắn nhất theo số bước di chuyển nếu lời giải tồn tại. Nhược điểm là tiêu tốn nhiều bộ nhớ khi không gian trạng thái lớn.

DFS (Depth-First Search)

DFS sử dụng ngăn xếp LIFO (Last In First Out). Thuật toán đi sâu vào một nhánh trước khi quay lui để khám phá các nhánh khác. DFS thường sử dụng ít bộ nhớ hơn BFS nhưng không đảm bảo tìm được lời giải ngắn nhất.

IDS (Iterative Deepening Search)

IDS thực hiện DFS với giới hạn độ sâu tăng dần từ 0, 1, 2, 3,... cho đến khi tìm thấy lời giải. Thuật toán kết hợp được ưu điểm của BFS và DFS: sử dụng ít bộ nhớ nhưng vẫn đảm bảo tìm được lời giải ngắn nhất.

UCS (Uniform Cost Search)

Trong phiên bản này, chi phí của mỗi trạng thái được xác định bằng số ô sai vị trí so với trạng thái Goal. Frontier được sắp xếp theo giá trị chi phí này và trạng thái có chi phí nhỏ hơn sẽ được ưu tiên mở rộng trước.

Greedy Search

Greedy Search sử dụng heuristic Manhattan Distance. Giá trị heuristic được tính bằng tổng khoảng cách Manhattan từ vị trí hiện tại của mỗi ô đến vị trí đích của ô đó trong trạng thái Goal. Thuật toán luôn ưu tiên mở rộng trạng thái có heuristic nhỏ nhất.

A*

Theo yêu cầu của bài tập:

h(n): số ô sai vị trí so với Goal.
g(n): số cặp nghịch thế (Inversion Count).
f(n) = g(n) + h(n).

Trong chương trình, chi phí của trạng thái Start cũng được tính vào tổng chi phí và giá trị g(n) được cộng dồn từ các trạng thái trước đó.

IDA*

Theo yêu cầu của bài tập:

h(n): số ô sai vị trí so với Goal.
g(n): Manhattan Distance.
f(n) = g(n) + h(n).

Tương tự A*, chi phí của trạng thái Start được tính vào tổng chi phí và giá trị g(n) được cộng dồn trong quá trình tìm kiếm. Thuật toán sử dụng cơ chế Threshold để giới hạn không gian tìm kiếm.

Hill Climbing

Hill Climbing sử dụng heuristic là số ô sai vị trí so với Goal.

Quá trình thực hiện:

Current State được khởi tạo bằng trạng thái Start.
Sinh các trạng thái lân cận theo thứ tự Left, Right, Up, Down.
Khi gặp trạng thái đầu tiên có heuristic nhỏ hơn Current State, thuật toán chuyển ngay sang trạng thái đó.
Nếu không tồn tại trạng thái nào tốt hơn, thuật toán dừng lại tại cực trị cục bộ (Local Optimum).

Best Hill Climbing (Steepest-Ascent Hill Climbing)

Best Hill Climbing cũng sử dụng heuristic là số ô sai vị trí so với Goal.

Quá trình thực hiện:

Sinh toàn bộ các trạng thái lân cận.
Tính heuristic cho tất cả các trạng thái con.
Chọn trạng thái có heuristic nhỏ nhất trong số các trạng thái được sinh ra.
Nếu không có trạng thái nào tốt hơn Current State thì thuật toán dừng.

Hill Climbing chọn trạng thái tốt đầu tiên tìm được, trong khi Best Hill Climbing chọn trạng thái tốt nhất trong toàn bộ các trạng thái lân cận.

Stochastic Hill Climbing

Sử dụng heuristic Manhattan Distance. Thuật toán sinh các trạng thái lân cận tốt hơn trạng thái hiện tại và chọn ngẫu nhiên một trạng thái trong số đó để tiếp tục tìm kiếm. Nếu không còn trạng thái nào tốt hơn, thuật toán dừng tại cực trị cục bộ.

Random Restart Hill Climbing

Sử dụng heuristic Manhattan Distance kết hợp Stochastic Hill Climbing. Khi rơi vào cực trị cục bộ, thuật toán khởi động lại từ một trạng thái ngẫu nhiên mới và tiếp tục tìm kiếm. Quá trình được lặp lại cho đến khi tìm thấy lời giải hoặc đạt số lần khởi động lại tối đa.

Local Beam Search

Local Beam Search duy trì đồng thời k trạng thái tốt nhất. Ở bước khởi tạo, thuật toán sinh k trạng thái ban đầu từ Start bằng các bước đi ngẫu nhiên. Sau đó, ở mỗi vòng lặp, thuật toán sinh toàn bộ trạng thái lân cận của k trạng thái hiện tại, tính heuristic Manhattan cho từng trạng thái, sắp xếp tăng dần theo heuristic và giữ lại k trạng thái tốt nhất để tiếp tục.


Cách chạy chương trình

Yêu cầu:

Python 3.10 hoặc mới hơn.
Tkinter.

Khởi chạy chương trình bằng lệnh:

python main.py

Ví dụ

Start:

1 2 3

4 0 6

7 5 8

Goal:

1 2 3

4 5 6

7 8 0

