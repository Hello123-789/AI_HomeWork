from tkinter import messagebox


class EightPuzzleController:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.path = []
        self.snapshots = []
        self.current_step = 0
        self.display_mode = "search"

        self.view.set_callbacks(
            self.solve,
            self.prev_step,
            self.next_step
        )

    def parse_input(self, text):
        parts = text.replace(",", " ").split()

        if len(parts) != 9:
            raise ValueError("Phải nhập đúng 9 số.")

        nums = [int(x) for x in parts]

        if sorted(nums) != list(range(9)):
            raise ValueError("Input phải chứa số từ 0 đến 8.")

        return tuple(nums)

    def get_move_name(self, prev_state, next_state):
        z1 = prev_state.index(0)
        z2 = next_state.index(0)
        diff = z2 - z1

        if diff == -3:
            return "UP"
        if diff == 3:
            return "DOWN"
        if diff == -1:
            return "LEFT"
        if diff == 1:
            return "RIGHT"

        return ""

    def _is_hill_algorithm(self, algorithm):
        return algorithm in {
            "HILL CLIMBING",
            "HILL",
            "SIMPLE HILL CLIMBING",
            "BEST HILL CLIMBING",
            "BEST HILL"
        }

    def _is_detail_hill_algorithm(self, algorithm):
        return algorithm in {
            "STOCHASTIC HILL CLIMBING",
            "STOCHASTIC HILL",
            "RANDOM RESTART HILL CLIMBING",
            "RANDOM RESTART HILL"
        }

    def _is_beam_algorithm(self, algorithm):
        return algorithm in {
            "LOCAL BEAM SEARCH",
            "BEAM SEARCH",
            "LOCAL BEAM"
        }

    def _solve_by_algorithm(self, algorithm, start, goal):
        algorithm = algorithm.upper()

        if algorithm == "BFS":
            return self.model.bfs(start, goal)
        if algorithm == "DFS":
            return self.model.dfs(start, goal)
        if algorithm == "IDS":
            return self.model.ids(start, goal)
        if algorithm == "UCS":
            return self.model.ucs(start, goal)
        if algorithm == "GREEDY":
            return self.model.greedy(start, goal)
        if algorithm in ("A*", "ASTAR", "A_STAR"):
            return self.model.a_star(start, goal)
        if algorithm in ("IDA*", "IDASTAR", "IDA_STAR"):
            return self.model.ida_star(start, goal)
        if algorithm in ("HILL CLIMBING", "HILL", "SIMPLE HILL CLIMBING"):
            return self.model.simple_hill_climbing(start, goal)
        if algorithm in ("BEST HILL CLIMBING", "BEST HILL"):
            return self.model.best_hill_climbing(start, goal)
        if algorithm in ("STOCHASTIC HILL CLIMBING", "STOCHASTIC HILL"):
            return self.model.stochastic_hill_climbing(start, goal)
        if algorithm in ("RANDOM RESTART HILL CLIMBING", "RANDOM RESTART HILL"):
            return self.model.random_restart_hill_climbing(start, goal)
        if algorithm in ("LOCAL BEAM SEARCH", "BEAM SEARCH", "LOCAL BEAM"):
            try:
                k = int(self.view.beam_k_var.get())
            except (TypeError, ValueError):
                raise ValueError("k phải là số nguyên dương.")
            if k < 1:
                raise ValueError("k phải là số nguyên dương.")
            return self.model.local_beam_search(start, goal, k)

        raise ValueError("Thuật toán không hợp lệ.")

    def build_moves(self, path):
        moves = []
        for i in range(len(path) - 1):
            cur = path[i]
            nxt = path[i + 1]

            cur_zero = cur.index(0)
            nxt_zero = nxt.index(0)

            if nxt_zero == cur_zero - 3:
                moves.append("UP")
            elif nxt_zero == cur_zero + 3:
                moves.append("DOWN")
            elif nxt_zero == cur_zero - 1:
                moves.append("LEFT")
            elif nxt_zero == cur_zero + 1:
                moves.append("RIGHT")
            else:
                moves.append("?")
        return moves

    def solve(self):
        try:
            start = self.parse_input(
                self.view.start_text.get("1.0", "end")
            )
            goal = self.parse_input(
                self.view.goal_text.get("1.0", "end")
            )
        except ValueError as e:
            messagebox.showerror("Lỗi", str(e))
            return

        if not self.model.is_solvable(start, goal):
            messagebox.showinfo("Thông báo", "Puzzle không giải được.")
            return

        algorithm = self.view.algorithm_var.get().strip().upper()
        if self._is_detail_hill_algorithm(algorithm):
            self.display_mode = "hill_detail"
        elif self._is_beam_algorithm(algorithm):
            self.display_mode = "beam"
        elif self._is_hill_algorithm(algorithm):
            self.display_mode = "hill"
        else:
            self.display_mode = "search"
        self.view.set_left_panel_mode(self.display_mode)

        try:
            result, snapshots = self._solve_by_algorithm(
                algorithm,
                start,
                goal
            )
        except ValueError as e:
            messagebox.showerror("Lỗi", str(e))
            return

        self.snapshots = snapshots
        self.current_step = 0

        if result is None:
            messagebox.showinfo("Thông báo", "Không tìm thấy lời giải.")
            return

        self.path = result
        moves = self.build_moves(self.path)
        self.view.draw_solution_tree(self.path, moves)
        self.show_current_step()

        if self.display_mode in ("hill", "hill_detail", "beam") and self.path[-1] != goal:
            self.view.update_status(
                f"{algorithm}: dừng trước khi tới goal."
            )
        else:
            self.view.update_status(
                f"Đã tìm thấy lời giải bằng {algorithm}, số bước: {len(self.path) - 1}"
            )

    def show_current_step(self):
        if not self.snapshots:
            return

        snapshot = self.snapshots[self.current_step]

        if self.display_mode == "hill":
            current_state = snapshot.get("current_state") or snapshot.get("node")
            next_state = snapshot.get("next_state")
            current_h = snapshot.get("current_h")
            next_h = snapshot.get("next_h")
            self.view.update_board(current_state)
            self.view.show_current_state(current_state, current_h)
            self.view.show_next_state(next_state, next_h)
        elif self.display_mode == "hill_detail":
            current_state = snapshot.get("current_state") or snapshot.get("node")
            next_state = snapshot.get("next_state")
            better_neighbors = snapshot.get("better_neighbors", [])
            current_h = snapshot.get("current_h")
            next_h = snapshot.get("next_h")
            self.view.update_board(current_state)
            self.view.show_current_state(current_state, current_h)
            self.view.show_next_state(next_state, next_h)
            self.view.show_better_neighbors(better_neighbors)
        elif self.display_mode == "beam":
            current_set = snapshot.get("current_state_set", [])
            neighbor_states = snapshot.get("neighbor_states", [])
            selected_states = snapshot.get("selected_states", [])
            active_state = snapshot.get("board_state") or snapshot.get("active_state")
            if active_state is None and current_set:
                first = current_set[0]
                active_state = first.get("state") if isinstance(first, dict) else first
            self.view.update_board(active_state)
            self.view.show_frontier(current_set)
            self.view.show_reached(neighbor_states, include_heuristic=True)
            self.view.show_better_neighbors(selected_states)
        else:
            self.view.update_board(snapshot["node"])
            self.view.show_frontier(snapshot["frontier"])
            self.view.show_reached(snapshot["reached"])

        if self.display_mode in ("hill", "hill_detail", "beam"):
            self.view.update_step_info(
                self.current_step,
                max(len(self.snapshots) - 1, 0)
            )
        else:
            self.view.update_step_info(
                self.current_step,
                len(self.snapshots) - 1
            )

    def prev_step(self):
        if self.current_step > 0:
            self.current_step -= 1
            self.show_current_step()

    def next_step(self):
        if self.current_step < len(self.snapshots) - 1:
            self.current_step += 1
            self.show_current_step()
