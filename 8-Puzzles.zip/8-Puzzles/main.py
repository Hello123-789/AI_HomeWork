import tkinter as tk
from model import EightPuzzleModel
from view import EightPuzzleView
from controller import EightPuzzleController


def main():
    root = tk.Tk()
    model = EightPuzzleModel()
    view = EightPuzzleView(root)
    EightPuzzleController(model, view)
    root.mainloop()


if __name__ == "__main__":
    main()
