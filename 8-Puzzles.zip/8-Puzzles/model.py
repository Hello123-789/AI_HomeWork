from collections import deque
import heapq
import random
from typing import Deque, Dict, List, Optional, Tuple, Callable, Set, Any

State = Tuple[int, ...]


class EightPuzzleModel:
    def inversion_count(self, state: State) -> int:
        nums = [x for x in state if x != 0]
        inv = 0
        for i in range(len(nums)):
            for j in range(i + 1, len(nums)):
                if nums[i] > nums[j]:
                    inv += 1
        return inv

    def is_solvable(self, start: State, goal: State) -> bool:
        return self.inversion_count(start) % 2 == self.inversion_count(goal) % 2

    def get_neighbors(self, node: State) -> List[State]:
        zero_idx = node.index(0)
        row, col = divmod(zero_idx, 3)

        moves: List[int] = []
        if col > 0:
            moves.append(zero_idx - 1)   
        if col < 2:
            moves.append(zero_idx + 1) 
        if row > 0:
            moves.append(zero_idx - 3)  
        if row < 2:
            moves.append(zero_idx + 3) 
        result: List[State] = []
        for nidx in moves:
            child = list(node)
            child[zero_idx], child[nidx] = child[nidx], child[zero_idx]
            result.append(tuple(child))
        return result

    def misplaced_tiles(self, state: State, goal: State) -> int:
        return sum(
            1
            for i, value in enumerate(state)
            if value != 0 and value != goal[i]
        )

    def manhattan_distance(self, state: State, goal: State) -> int:
        goal_pos = {
            value: divmod(idx, 3)
            for idx, value in enumerate(goal)
        }

        total = 0
        for idx, value in enumerate(state):
            if value == 0:
                continue
            row, col = divmod(idx, 3)
            goal_row, goal_col = goal_pos[value]
            total += abs(row - goal_row) + abs(col - goal_col)
        return total

    def astar_g_cost(self, state: State, goal: State) -> int:
        return self.inversion_count(state)

    def ida_g_cost(self, state: State, goal: State) -> int:
        return self.manhattan_distance(state, goal)

    def reconstruct_path(
        self,
        parent: Dict[State, Optional[State]],
        goal: State
    ) -> List[State]:
        path: List[State] = []
        cur: Optional[State] = goal
        while cur is not None:
            path.append(cur)
            cur = parent[cur]
        path.reverse()
        return path

    def _snapshot(
        self,
        node: State,
        frontier: Any,
        reached: Any
    ) -> Dict[str, object]:
        return {
            "node": node,
            "frontier": frontier,
            "reached": reached
        }

    def _priority_frontier_snapshot(self, heap):
        ordered = sorted(heap)
        result = []
        for item in ordered:
            if len(item) == 3:
                cost, _, state = item
                result.append({"state": state, "cost": cost})
            elif len(item) == 5:
                f_cost, _, state, g_cost, h_cost = item
                result.append({
                    "state": state,
                    "cost": f_cost,
                    "g": g_cost,
                    "h": h_cost,
                    "f": f_cost
                })
        return result


    def _hill_snapshot(
        self,
        current_state: State,
        next_state: Optional[State],
        current_h: int,
        next_h: Optional[int],
        better_neighbors: Optional[List[Dict[str, object]]] = None
    ) -> Dict[str, object]:
        snapshot = {
            "current_state": current_state,
            "next_state": next_state,
            "current_h": current_h,
            "next_h": next_h,
            "better_neighbors": better_neighbors or []
        }
        return snapshot


    def _hill_heuristic(self, state: State, goal: State, use_manhattan: bool = False) -> int:
        return self.manhattan_distance(state, goal) if use_manhattan else self.misplaced_tiles(state, goal)

    def _better_neighbors(
        self,
        current: State,
        goal: State,
        use_manhattan: bool = False
    ) -> List[Dict[str, object]]:
        current_h = self._hill_heuristic(current, goal, use_manhattan)
        better_neighbors: List[Dict[str, object]] = []

        for neighbor in self.get_neighbors(current):
            next_h = self._hill_heuristic(neighbor, goal, use_manhattan)
            if next_h < current_h:
                better_neighbors.append({
                    "state": neighbor,
                    "h": next_h
                })

        return better_neighbors

    def bfs(self, start: State, goal: State):
        frontier: Deque[State] = deque([start])
        parent: Dict[State, Optional[State]] = {start: None}
        snapshots = [self._snapshot(start, [start], [start])]

        while frontier:
            node = frontier.popleft()

            if node == goal:
                return self.reconstruct_path(parent, goal), snapshots

            for child_state in self.get_neighbors(node):
                if child_state in parent:
                    continue

                parent[child_state] = node
                frontier.append(child_state)
                snapshots.append(
                    self._snapshot(
                        child_state,
                        list(frontier),
                        list(parent.keys())
                    )
                )

        return None, snapshots

    def dfs(self, start: State, goal: State):
        stack: List[State] = [start]
        parent: Dict[State, Optional[State]] = {start: None}
        snapshots = [self._snapshot(start, [start], [start])]

        while stack:
            node = stack.pop()

            if node == goal:
                return self.reconstruct_path(parent, goal), snapshots

            for child_state in self.get_neighbors(node):
                if child_state in parent:
                    continue

                parent[child_state] = node
                stack.append(child_state)
                snapshots.append(
                    self._snapshot(
                        child_state,
                        list(reversed(stack)),
                        list(parent.keys())
                    )
                )

        return None, snapshots

    def depth_limited_search(self, start: State, goal: State, limit: int):
        stack: List[Tuple[State, int]] = [(start, 0)]
        parent: Dict[State, Optional[State]] = {start: None}
        snapshots = [self._snapshot(start, [start], [start])]
        cutoff = False

        while stack:
            node, depth = stack.pop()

            if node == goal:
                return self.reconstruct_path(parent, goal), snapshots, False

            if depth >= limit:
                cutoff = True
                continue

            for child_state in self.get_neighbors(node):
                if child_state in parent:
                    continue

                parent[child_state] = node
                stack.append((child_state, depth + 1))
                snapshots.append(
                    self._snapshot(
                        child_state,
                        [state for state, _ in reversed(stack)],
                        list(parent.keys())
                    )
                )

        return None, snapshots, cutoff

    def ids(self, start: State, goal: State, max_depth: int = 31):
        last_snapshots = []
        for depth in range(max_depth + 1):
            result, snapshots, cutoff = self.depth_limited_search(start, goal, depth)
            last_snapshots = snapshots

            if result is not None:
                return result, snapshots

            if not cutoff:
                return None, snapshots

        return None, last_snapshots

    def best_first_search(
        self,
        start: State,
        goal: State,
        cost_fn: Callable[[State, State], int]
    ):
        heap = []
        counter = 0
        parent: Dict[State, Optional[State]] = {start: None}
        discovered: Set[State] = {start}

        start_cost = cost_fn(start, goal)
        heapq.heappush(heap, (start_cost, counter, start))
        counter += 1

        snapshots = [
            self._snapshot(
                start,
                [{"state": start, "cost": start_cost}],
                [start]
            )
        ]

        while heap:
            current_cost, _, node = heapq.heappop(heap)

            if node == goal:
                return self.reconstruct_path(parent, goal), snapshots

            for child_state in self.get_neighbors(node):
                if child_state in discovered:
                    continue

                discovered.add(child_state)
                parent[child_state] = node
                child_cost = cost_fn(child_state, goal)
                heapq.heappush(heap, (child_cost, counter, child_state))
                counter += 1

                snapshots.append(
                    self._snapshot(
                        child_state,
                        self._priority_frontier_snapshot(heap),
                        list(parent.keys())
                    )
                )

        return None, snapshots

    def astar_search(
        self,
        start: State,
        goal: State,
        g_cost_fn: Callable[[State, State], int],
        h_cost_fn: Callable[[State, State], int]
    ):
        heap = []
        counter = 0
        parent: Dict[State, Optional[State]] = {start: None}
        best_g: Dict[State, int] = {start: g_cost_fn(start, goal)}

        start_g = best_g[start]
        start_h = h_cost_fn(start, goal)
        start_f = start_g + start_h

        heapq.heappush(heap, (start_f, counter, start, start_g, start_h))
        counter += 1

        snapshots = [
            self._snapshot(
                start,
                [{
                    "state": start,
                    "cost": start_f,
                    "g": start_g,
                    "h": start_h,
                    "f": start_f
                }],
                [start]
            )
        ]

        while heap:
            current_f, _, node, current_g, current_h = heapq.heappop(heap)

            if current_g != best_g.get(node):
                continue

            if node == goal:
                return self.reconstruct_path(parent, goal), snapshots

            for child_state in self.get_neighbors(node):
                child_g = current_g + g_cost_fn(child_state, goal)
                child_h = h_cost_fn(child_state, goal)
                child_f = child_g + child_h

                if child_g >= best_g.get(child_state, float("inf")):
                    continue

                best_g[child_state] = child_g
                parent[child_state] = node
                heapq.heappush(heap, (child_f, counter, child_state, child_g, child_h))
                counter += 1

                snapshots.append(
                    self._snapshot(
                        child_state,
                        self._priority_frontier_snapshot(heap),
                        list(parent.keys())
                    )
                )

        return None, snapshots

    def a_star(self, start: State, goal: State):
        return self.astar_search(start, goal, self.astar_g_cost, self.misplaced_tiles)

    def ida_star(self, start: State, goal: State, max_depth: int = 80):
        start_g = self.ida_g_cost(start, goal)
        start_h = self.misplaced_tiles(start, goal)
        threshold = start_g + start_h

        parent: Dict[State, Optional[State]] = {start: None}
        path: List[State] = [start]

        snapshots = [
            self._snapshot(
                start,
                [{
                    "state": start,
                    "cost": threshold,
                    "g": start_g,
                    "h": start_h,
                    "f": threshold
                }],
                [start]
            )
        ]

        def build_path_snapshot() -> List[Dict[str, object]]:
            frontier_snapshot: List[Dict[str, object]] = []
            cumulative_g = 0

            for idx, s in enumerate(path):
                s_h = self.misplaced_tiles(s, goal)

                if idx == 0:
                    s_g = self.ida_g_cost(s, goal)
                    cumulative_g = s_g
                else:
                    step_cost = self.ida_g_cost(s, goal)
                    cumulative_g += step_cost
                    s_g = cumulative_g

                frontier_snapshot.append({
                    "state": s,
                    "cost": s_g + s_h,
                    "g": s_g,
                    "h": s_h,
                    "f": s_g + s_h
                })

            return frontier_snapshot

        def search(node: State, g_cost: int, limit: int, depth: int):
            h_cost = self.misplaced_tiles(node, goal)
            f_cost = g_cost + h_cost

            if f_cost > limit:
                return f_cost

            if node == goal:
                return "FOUND"

            if depth >= max_depth:
                return float("inf")

            min_over_limit = float("inf")

            candidates = []
            for child_state in self.get_neighbors(node):
                if child_state in path:
                    continue

                child_g = g_cost + self.ida_g_cost(child_state, goal)
                child_h = self.misplaced_tiles(child_state, goal)
                child_f = child_g + child_h
                candidates.append((child_f, child_state, child_g, child_h))

            candidates.sort(key=lambda item: item[0])

            for child_f, child_state, child_g, child_h in candidates:
                parent[child_state] = node
                path.append(child_state)

                snapshots.append(
                    self._snapshot(
                        child_state,
                        build_path_snapshot(),
                        list(parent.keys())
                    )
                )

                result = search(child_state, child_g, limit, depth + 1)

                if result == "FOUND":
                    return "FOUND"

                if result < min_over_limit:
                    min_over_limit = result

                path.pop()
                parent.pop(child_state, None)

            return min_over_limit

        while True:
            result = search(start, start_g, threshold, 0)

            if result == "FOUND":
                return self.reconstruct_path(parent, goal), snapshots

            if result == float("inf"):
                return None, snapshots

            threshold = result



    def simple_hill_climbing(self, start: State, goal: State):
        current = start
        path: List[State] = [current]
        snapshots = [
            self._hill_snapshot(
                current,
                None,
                self.misplaced_tiles(current, goal),
                None
            )
        ]

        while True:
            current_h = self.misplaced_tiles(current, goal)
            moved = False

            for next_state in self.get_neighbors(current):
                next_h = self.misplaced_tiles(next_state, goal)
                snapshots.append(
                    self._hill_snapshot(current, next_state, current_h, next_h)
                )

                if next_h < current_h:
                    current = next_state
                    path.append(current)
                    moved = True
                    break

            if not moved:
                break

        return path, snapshots

    def best_hill_climbing(self, start: State, goal: State):
        current = start
        path: List[State] = [current]
        snapshots = [
            self._hill_snapshot(
                current,
                None,
                self.misplaced_tiles(current, goal),
                None
            )
        ]

        while True:
            current_h = self.misplaced_tiles(current, goal)
            best_state: Optional[State] = None
            best_h = current_h

            for next_state in self.get_neighbors(current):
                next_h = self.misplaced_tiles(next_state, goal)
                snapshots.append(
                    self._hill_snapshot(current, next_state, current_h, next_h)
                )

                if next_h < best_h:
                    best_h = next_h
                    best_state = next_state

            if best_state is None:
                break

            current = best_state
            path.append(current)

        return path, snapshots

    def stochastic_hill_climbing(self, start: State, goal: State):
        current = start
        path: List[State] = [current]
        snapshots = [
            self._hill_snapshot(
                current,
                None,
                self._hill_heuristic(current, goal, use_manhattan=True),
                None,
                []
            )
        ]

        if current == goal:
            return path, snapshots

        while True:
            current_h = self._hill_heuristic(current, goal, use_manhattan=True)
            better_neighbors = self._better_neighbors(current, goal, use_manhattan=True)

            if not better_neighbors:
                snapshots.append(
                    self._hill_snapshot(
                        current,
                        None,
                        current_h,
                        None,
                        []
                    )
                )
                break

            next_choice = random.choice(better_neighbors)
            next_state = next_choice["state"]
            next_h = next_choice["h"]

            snapshots.append(
                self._hill_snapshot(
                    current,
                    next_state,
                    current_h,
                    next_h,
                    better_neighbors
                )
            )

            if next_state == goal:
                path.append(next_state)
                break

            current = next_state
            path.append(current)

        return path, snapshots

    def random_restart_hill_climbing(self, start: State, goal: State, max_restart: int = 5):
        all_snapshots: List[Dict[str, object]] = []

        for _ in range(max_restart):
            current = start
            path: List[State] = [current]
            all_snapshots.append(
                self._hill_snapshot(
                    current,
                    None,
                    self._hill_heuristic(current, goal, use_manhattan=True),
                    None,
                    []
                )
            )

            if current == goal:
                return path, all_snapshots

            while True:
                current_h = self._hill_heuristic(current, goal, use_manhattan=True)
                better_neighbors = self._better_neighbors(current, goal, use_manhattan=True)

                if not better_neighbors:
                    all_snapshots.append(
                        self._hill_snapshot(
                            current,
                            None,
                            current_h,
                            None,
                            []
                        )
                    )
                    break

                next_choice = random.choice(better_neighbors)
                next_state = next_choice["state"]
                next_h = next_choice["h"]

                all_snapshots.append(
                    self._hill_snapshot(
                        current,
                        next_state,
                        current_h,
                        next_h,
                        better_neighbors
                    )
                )

                if next_state == goal:
                    path.append(next_state)
                    return path, all_snapshots

                current = next_state
                path.append(current)

        return None, all_snapshots

    def _random_walk_path(self, start: State, steps: int) -> List[State]:
        path: List[State] = [start]
        current = start
        previous: Optional[State] = None

        for _ in range(max(0, steps)):
            neighbors = self.get_neighbors(current)

            if previous is not None and len(neighbors) > 1:
                filtered = [state for state in neighbors if state != previous]
                if filtered:
                    neighbors = filtered

            next_state = random.choice(neighbors)
            path.append(next_state)
            previous = current
            current = next_state

        return path

    def _build_initial_beam(
        self,
        start: State,
        k: int,
        parent: Dict[State, Optional[State]]
    ) -> List[State]:
        current_state_set: List[State] = []
        seen: Set[State] = {start}
        attempts = 0
        max_attempts = max(50, k * 30)

        while len(current_state_set) < k and attempts < max_attempts:
            attempts += 1
            walk_length = random.randint(1, 4 + k)
            walk = self._random_walk_path(start, walk_length)
            candidate = walk[-1]

            if candidate in seen:
                continue

            for prev_state, next_state in zip(walk, walk[1:]):
                parent.setdefault(next_state, prev_state)

            current_state_set.append(candidate)
            seen.add(candidate)

        if len(current_state_set) < k:
            for neighbor in self.get_neighbors(start):
                if neighbor in seen:
                    continue
                parent.setdefault(neighbor, start)
                current_state_set.append(neighbor)
                seen.add(neighbor)
                if len(current_state_set) == k:
                    break
        if not current_state_set:
            current_state_set.append(start)

        return current_state_set[:k]

    def _beam_heuristic(self, state: State, goal: State) -> int:
        return self.manhattan_distance(state, goal)

    def _beam_snapshot(
        self,
        current_state_set: List[State],
        neighbor_states: List[Dict[str, object]],
        selected_states: List[Dict[str, object]],
        goal: State,
        board_state: Optional[State] = None
    ) -> Dict[str, object]:
        def pack(states):
            packed: List[Dict[str, object]] = []
            for item in states:
                if isinstance(item, dict):
                    if "state" in item:
                        state = item["state"]
                        h = item.get("h")
                        if h is None and isinstance(state, tuple):
                            h = self._beam_heuristic(state, goal)
                        packed.append({
                            **item,
                            **({"h": h} if h is not None else {})
                        })
                    else:
                        packed.append(item)
                else:
                    packed.append({
                        "state": item,
                        "h": self._beam_heuristic(item, goal)
                    })
            return packed

        return {
            "current_state_set": pack(current_state_set),
            "neighbor_states": pack(neighbor_states),
            "selected_states": pack(selected_states),
            "active_state": board_state if board_state is not None else (
                current_state_set[0]["state"]
                if current_state_set and isinstance(current_state_set[0], dict)
                else current_state_set[0]
                if current_state_set
                else None
            ),
            "board_state": board_state
        }

    def local_beam_search(
        self,
        start: State,
        goal: State,
        k: int = 3,
        max_iterations: int = 100
    ):
        if k < 1:
            raise ValueError("k phải lớn hơn 0.")

        parent: Dict[State, Optional[State]] = {start: None}
        current_state_set = self._build_initial_beam(start, k, parent)

        snapshots = [self._beam_snapshot([], [], [], goal, board_state=start)]
        seen_beams: Set[frozenset[State]] = {frozenset(current_state_set)}

        snapshots.append(
            self._beam_snapshot(
                current_state_set,
                [],
                [],
                goal,
                board_state=current_state_set[0] if current_state_set else start
            )
        )

        if goal in current_state_set:
            return self.reconstruct_path(parent, goal), snapshots

        fallback_state = current_state_set[0] if current_state_set else start

        for _ in range(max_iterations):
            neighbor_states: List[Dict[str, object]] = []
            seen_neighbors: Set[State] = set(current_state_set)
            for state in current_state_set:
                for neighbor in self.get_neighbors(state):
                    if neighbor in seen_neighbors:
                        continue

                    seen_neighbors.add(neighbor)
                    parent.setdefault(neighbor, state)
                    neighbor_states.append({
                        "state": neighbor,
                        "h": self._beam_heuristic(neighbor, goal)
                    })

            neighbor_states.sort(key=lambda item: item["h"])

            # Bước 2: hiển thị các Neighbor_States đã sinh.
            snapshots.append(
                self._beam_snapshot(
                    current_state_set,
                    neighbor_states,
                    [],
                    goal,
                    board_state=current_state_set[0] if current_state_set else None
                )
            )

            if any(item["state"] == goal for item in neighbor_states):
                goal_neighbors = [item for item in neighbor_states if item["state"] == goal]
                snapshots.append(
                    self._beam_snapshot(
                        goal_neighbors,
                        neighbor_states,
                        goal_neighbors[:k],
                        goal,
                        board_state=goal
                    )
                )
                return self.reconstruct_path(parent, goal), snapshots

            selected_states = neighbor_states[:k]

            # Bước 3: chọn k trạng thái tốt nhất.
            snapshots.append(
                self._beam_snapshot(
                    selected_states,
                    neighbor_states,
                    selected_states,
                    goal,
                    board_state=selected_states[0]["state"] if selected_states else current_state_set[0]
                )
            )

            if not selected_states:
                break

            next_state_set = [item["state"] for item in selected_states]
            fallback_state = next_state_set[0]
            next_key = frozenset(next_state_set)

            if next_key in seen_beams:
                current_state_set = next_state_set
                break

            seen_beams.add(next_key)
            current_state_set = next_state_set

            if goal in current_state_set:
                return self.reconstruct_path(parent, goal), snapshots

        if fallback_state not in parent:
            return None, snapshots

        return self.reconstruct_path(parent, fallback_state), snapshots


    def ucs(self, start: State, goal: State):
        return self.best_first_search(start, goal, self.misplaced_tiles)

    def greedy(self, start: State, goal: State):
        return self.best_first_search(start, goal, self.manhattan_distance)