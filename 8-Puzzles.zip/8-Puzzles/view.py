import tkinter as tk
from tkinter import ttk


class EightPuzzleView:
    BG = "#f4f7fb"
    PANEL = "#ffffff"
    PANEL_ALT = "#f8fbff"
    ACCENT = "#4f6ef7"
    ACCENT_DARK = "#3a56d4"
    TEXT = "#1f2937"
    MUTED = "#64748b"
    BORDER = "#d7def0"
    EMPTY_CELL = "#dfe6f3"
    CELL = "#ffffff"
    HIGHLIGHT = "#e7efff"

    def __init__(self, root):
        self.root = root
        self.root.title("8 Puzzle Explorer")
        self.root.geometry("1700x950")
        self.root.configure(bg=self.BG)

        self.cells = []
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        style = ttk.Style(self.root)

        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            ".",
            background=self.BG,
            foreground=self.TEXT,
            font=("Segoe UI", 10),
        )

        style.configure("App.TFrame", background=self.BG)
        style.configure("Card.TFrame", background=self.PANEL)

        style.configure(
            "Section.TLabel",
            background=self.BG,
            foreground=self.TEXT,
            font=("Segoe UI", 11, "bold"),
        )

        style.configure(
            "Title.TLabel",
            background=self.BG,
            foreground=self.ACCENT_DARK,
            font=("Segoe UI", 16, "bold"),
        )

        style.configure(
            "Info.TLabel",
            background=self.BG,
            foreground=self.MUTED,
            font=("Segoe UI", 10),
        )

        style.configure(
            "Accent.TButton",
            background=self.ACCENT,
            foreground="white",
            padding=(14, 8),
            borderwidth=0,
        )

        style.map(
            "Accent.TButton",
            background=[("active", self.ACCENT_DARK)],
            foreground=[("disabled", "#dbe4ff")],
        )

        style.configure(
            "Neutral.TButton",
            background="#e8edf8",
            foreground=self.TEXT,
            padding=(14, 8),
            borderwidth=0,
        )

        style.map(
            "Neutral.TButton",
            background=[("active", self.HIGHLIGHT), ("pressed", self.HIGHLIGHT)],
        )

        style.configure("Algo.TCombobox", padding=6)

    def build_ui(self):
        main = ttk.Frame(self.root, padding=12, style="App.TFrame")
        main.pack(fill="both", expand=True)

        left_container = ttk.Frame(main, style="Card.TFrame")
        left_container.pack(side="left", fill="y", padx=(0, 12))

        left_canvas = tk.Canvas(
            left_container,
            width=350,
            height=880,
            bg=self.PANEL,
            highlightthickness=0,
            bd=0,
        )
        left_canvas.pack(side="left", fill="y", expand=False)

        left_scrollbar = ttk.Scrollbar(
            left_container,
            orient="vertical",
            command=left_canvas.yview,
        )
        left_scrollbar.pack(side="right", fill="y")

        left_canvas.configure(yscrollcommand=left_scrollbar.set)

        left = ttk.Frame(left_canvas, style="Card.TFrame")
        left_window = left_canvas.create_window((0, 0), window=left, anchor="nw")

        def _sync_left_scrollregion(event=None):
            left_canvas.configure(scrollregion=left_canvas.bbox("all"))

        def _sync_left_width(event):
            left_canvas.itemconfigure(left_window, width=event.width)

        left.bind("<Configure>", _sync_left_scrollregion)
        left_canvas.bind("<Configure>", _sync_left_width)

        self.left_primary_label = ttk.Label(left, text="Frontier", style="Section.TLabel")
        self.left_primary_label.pack(anchor="w", padx=10, pady=(10, 4))

        frontier_frame = ttk.Frame(left, style="Card.TFrame")
        frontier_frame.pack(padx=10, pady=(0, 8))

        self.frontier_box = tk.Text(
            frontier_frame,
            width=28,
            height=14,
            wrap="none",
            bg=self.PANEL_ALT,
            fg=self.TEXT,
            font=("Consolas", 10),
            relief="flat",
            highlightthickness=1,
            highlightbackground=self.BORDER,
            padx=8,
            pady=8,
        )

        self.frontier_box.grid(row=0, column=0)

        frontier_scroll_y = ttk.Scrollbar(
            frontier_frame,
            orient="vertical",
            command=self.frontier_box.yview
        )
        frontier_scroll_y.grid(row=0, column=1, sticky="ns")

        frontier_scroll_x = ttk.Scrollbar(
            frontier_frame,
            orient="horizontal",
            command=self.frontier_box.xview
        )
        frontier_scroll_x.grid(row=1, column=0, sticky="ew")

        self.frontier_box.configure(
            yscrollcommand=frontier_scroll_y.set,
            xscrollcommand=frontier_scroll_x.set
        )

        self.left_secondary_label = ttk.Label(left, text="Reached", style="Section.TLabel")
        self.left_secondary_label.pack(anchor="w", padx=10, pady=(8, 4))

        reached_frame = ttk.Frame(left, style="Card.TFrame")
        reached_frame.pack(padx=10, pady=(0, 8))

        self.reached_box = tk.Text(
            reached_frame,
            width=28,
            height=14,
            wrap="none",
            bg=self.PANEL_ALT,
            fg=self.TEXT,
            font=("Consolas", 10),
            relief="flat",
            highlightthickness=1,
            highlightbackground=self.BORDER,
            padx=8,
            pady=8,
        )

        self.reached_box.grid(row=0, column=0)

        reached_scroll_y = ttk.Scrollbar(
            reached_frame,
            orient="vertical",
            command=self.reached_box.yview
        )
        reached_scroll_y.grid(row=0, column=1, sticky="ns")

        reached_scroll_x = ttk.Scrollbar(
            reached_frame,
            orient="horizontal",
            command=self.reached_box.xview
        )
        reached_scroll_x.grid(row=1, column=0, sticky="ew")

        self.reached_box.configure(
            yscrollcommand=reached_scroll_y.set,
            xscrollcommand=reached_scroll_x.set
        )

        self.better_label = ttk.Label(left, text="Better Neighbors", style="Section.TLabel")
        self.better_frame = ttk.Frame(left, style="Card.TFrame")
        self.better_box = tk.Text(
            self.better_frame,
            width=28,
            height=14,
            wrap="none",
            bg=self.PANEL_ALT,
            fg=self.TEXT,
            font=("Consolas", 10),
            relief="flat",
            highlightthickness=1,
            highlightbackground=self.BORDER,
            padx=8,
            pady=8,
        )
        self.better_box.grid(row=0, column=0)

        better_scroll_y = ttk.Scrollbar(
            self.better_frame,
            orient="vertical",
            command=self.better_box.yview
        )
        better_scroll_y.grid(row=0, column=1, sticky="ns")

        better_scroll_x = ttk.Scrollbar(
            self.better_frame,
            orient="horizontal",
            command=self.better_box.xview
        )
        better_scroll_x.grid(row=1, column=0, sticky="ew")

        self.better_box.configure(
            yscrollcommand=better_scroll_y.set,
            xscrollcommand=better_scroll_x.set
        )

        center = ttk.Frame(main, style="App.TFrame")
        center.pack(side="left", fill="both", expand=True)

        ttk.Label(
            center,
            text="8 Puzzle Explorer",
            style="Title.TLabel"
        ).pack(anchor="w", padx=8, pady=(0, 6))

        ttk.Label(
            center,
            text="Nhập trạng thái start và goal rồi chọn thuật toán.",
            style="Info.TLabel",
        ).pack(anchor="w", padx=8, pady=(0, 12))

        input_frame = ttk.Frame(center, style="Card.TFrame")
        input_frame.pack(anchor="n", fill="x", padx=6)

        input_left = ttk.Frame(input_frame, style="Card.TFrame")
        input_left.pack(side="left", padx=18, pady=14)

        ttk.Label(
            input_left,
            text="Input trạng thái start",
            style="Section.TLabel"
        ).pack(anchor="w")

        self.start_text = tk.Text(
            input_left,
            width=18,
            height=5,
            font=("Consolas", 12),
            bg="#ffffff",
            relief="flat",
            highlightthickness=1,
            highlightbackground=self.BORDER,
            padx=8,
            pady=8,
        )
        self.start_text.pack(pady=(6, 0))

        ttk.Label(
            input_left,
            text="Input trạng thái goal",
            style="Section.TLabel"
        ).pack(anchor="w", pady=(12, 0))

        self.goal_text = tk.Text(
            input_left,
            width=18,
            height=5,
            font=("Consolas", 12),
            bg="#ffffff",
            relief="flat",
            highlightthickness=1,
            highlightbackground=self.BORDER,
            padx=8,
            pady=8,
        )
        self.goal_text.pack(pady=(6, 0))

        input_right = ttk.Frame(input_frame, style="Card.TFrame")
        input_right.pack(side="left", padx=18, pady=14, anchor="n", fill="y")

        ttk.Label(input_right, text="Chọn thuật toán", style="Section.TLabel").pack(anchor="w")
        self.algorithm_var = tk.StringVar(value="BFS")
        self.algorithm_combo = ttk.Combobox(
            input_right,
            textvariable=self.algorithm_var,
            values=["BFS", "DFS", "IDS", "UCS", "GREEDY", "A*", "IDA*", "HILL CLIMBING", "BEST HILL CLIMBING", "STOCHASTIC HILL CLIMBING", "RANDOM RESTART HILL CLIMBING", "LOCAL BEAM SEARCH"],
            state="readonly",
            width=30,
            style="Algo.TCombobox",
        )
        self.algorithm_combo.pack(anchor="w", pady=(6, 8))
        self.algorithm_combo.current(0)
        self.algorithm_combo.bind("<<ComboboxSelected>>", self._update_beam_k_visibility)

        self.beam_k_row = ttk.Frame(input_right, style="Card.TFrame")


        ttk.Label(self.beam_k_row, text="k:", style="Section.TLabel").pack(side="left")


        self.beam_k_var = tk.StringVar(value="3")


        self.beam_k_entry = ttk.Entry(self.beam_k_row, textvariable=self.beam_k_var, width=6)


        self.beam_k_entry.pack(side="left", padx=(6, 0))


        self.beam_k_row.pack_forget()

        ttk.Label(
            input_right,
             text=(
        "BFS: tìm lời giải ngắn nhất\n"
        "DFS: đi sâu trước\n"
        "IDS: DFS sâu dần\n"
        "UCS: cost = số ô sai vị trí\n"
        "GREEDY: cost = Manhattan\n"
        "A*: g = số cặp nghịch thế , h = số ô sai vị trí \n"
        "IDA*: g = Manhattan , h = số ô sai ví trí\n"
        "HILL CLIMBING: h = số ô sai vị trí\n"
        "BEST HILL CLIMBING: h = số ô sai vị trí\n"
        "STOCHASTIC HILL CLIMBING: chọn ngẫu nhiên 1 trong các better neighbors\n"
        "RANDOM RESTART HILL CLIMBING: chạy lại nhiều lần\n"
        "LOCAL BEAM SEARCH:chọn k best states,h = Manhattan\n"
        "k: số trạng thái tốt nhất giữ lại mỗi vòng"
    ),
            style="Info.TLabel",
            justify="left",
        ).pack(anchor="w")

        button_frame = ttk.Frame(center, style="App.TFrame")
        button_frame.pack(pady=12)

        self.solve_button = ttk.Button(button_frame, text="Solve", style="Accent.TButton")
        self.solve_button.pack(side="left", padx=6)

        self.prev_button = ttk.Button(button_frame, text="Prev", style="Neutral.TButton")
        self.prev_button.pack(side="left", padx=6)

        self.next_button = ttk.Button(button_frame, text="Next", style="Neutral.TButton")
        self.next_button.pack(side="left", padx=6)

        self.status_label = ttk.Label(center, text="", style="Info.TLabel")
        self.status_label.pack(anchor="w", padx=8, pady=(0, 2))

        self.step_label = ttk.Label(center, text="", style="Info.TLabel")
        self.step_label.pack(anchor="w", padx=8, pady=(0, 8))

        ttk.Label(
            center,
            text="Ma trận hiện tại",
            style="Section.TLabel"
        ).pack(anchor="w", padx=8, pady=(8, 0))

        board_frame = ttk.Frame(center, style="Card.TFrame")
        board_frame.pack(pady=12, padx=8)

        for r in range(3):
            for c in range(3):
                lbl = tk.Label(
                    board_frame,
                    width=3,
                    height=1,
                    font=("Arial", 24, "bold"),
                    relief="solid",
                    bd=1,
                    bg=self.CELL,
                    fg=self.TEXT,
                    highlightthickness=0,
                )
                lbl.grid(row=r, column=c, padx=4, pady=4)
                self.cells.append(lbl)

        right = ttk.Frame(main, style="Card.TFrame", width=450)
        right.pack(side="right", fill="y", padx=(12, 0))
        right.pack_propagate(False)

        ttk.Label(right, text="Lời giải", style="Section.TLabel").pack(
            anchor="w", padx=10, pady=(10, 4)
        )

        tree_frame = ttk.Frame(right, style="Card.TFrame")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

        self.tree_canvas = tk.Canvas(
            tree_frame,
            bg=self.PANEL_ALT,
            width=400,
            height=660,
            scrollregion=(0, 0, 3000, 5000),
            highlightthickness=1,
            highlightbackground=self.BORDER,
            bd=0,
        )
        self.tree_canvas.grid(row=0, column=0, sticky="nsew")

        tree_scroll_y = ttk.Scrollbar(
            tree_frame,
            orient="vertical",
            command=self.tree_canvas.yview
        )
        tree_scroll_y.grid(row=0, column=1, sticky="ns")

        tree_scroll_x = ttk.Scrollbar(
            tree_frame,
            orient="horizontal",
            command=self.tree_canvas.xview
        )
        tree_scroll_x.grid(row=1, column=0, sticky="ew")

        self.tree_canvas.configure(
            yscrollcommand=tree_scroll_y.set,
            xscrollcommand=tree_scroll_x.set
        )

    def format_state(self, state):
        text = ""
        for r in range(0, 9, 3):
            row = state[r:r + 3]
            text += " ".join(str(x) if x != 0 else " " for x in row)
            text += "\n"
        return text

    def format_state_with_heuristic(self, state, heuristic):
        text = ""
        if heuristic is not None:
            text += f"h = {heuristic}\n"
        text += self.format_state(state)
        return text

    def format_frontier_item(self, item):
        state = item
        cost = None
        g_cost = None
        h_cost = None
        f_cost = None

        if isinstance(item, dict):
            state = item.get("state", item)
            cost = item.get("cost")
            g_cost = item.get("g")
            h_cost = item.get("h")
            f_cost = item.get("f")
        elif isinstance(item, tuple) and len(item) == 2 and isinstance(item[0], tuple):
            state, cost = item

        text = ""
        if g_cost is not None and h_cost is not None and f_cost is not None:
            text += f"g = {g_cost}, h = {h_cost}, f = {f_cost}\n"
        elif h_cost is not None:
            text += f"h = {h_cost}\n"
        elif cost is not None:
            text += f"cost = {cost}\n"
        text += self.format_state(state)
        return text

    def show_frontier(self, frontier):
        self.frontier_box.delete("1.0", tk.END)
        for i, item in enumerate(frontier, 1):
            self.frontier_box.insert(tk.END, f"[{i}]\n")
            self.frontier_box.insert(tk.END, self.format_frontier_item(item))
            self.frontier_box.insert(tk.END, "\n")

    def show_reached(self, reached, include_heuristic=False):
        self.reached_box.delete("1.0", tk.END)
        for i, item in enumerate(reached, 1):
            self.reached_box.insert(tk.END, f"[{i}]\n")
            if include_heuristic:
                self.reached_box.insert(tk.END, self.format_frontier_item(item))
            else:
                self.reached_box.insert(tk.END, self.format_state(item))
            self.reached_box.insert(tk.END, "\n")

    def set_left_panel_mode(self, mode):
        self.left_mode = mode

        # Hide or show the third section depending on the algorithm.
        if mode in ("hill_detail", "beam"):
            if not self.better_label.winfo_ismapped():
                self.better_label.pack(anchor="w", padx=10, pady=(8, 4))
            if not self.better_frame.winfo_ismapped():
                self.better_frame.pack(padx=10, pady=(0, 10))
        else:
            if self.better_frame.winfo_ismapped():
                self.better_frame.pack_forget()
            if self.better_label.winfo_ismapped():
                self.better_label.pack_forget()

        if mode == "hill" or mode == "hill_detail":
            self.left_primary_label.config(text="Current State")
            self.left_secondary_label.config(text="Next State")
            self.better_label.config(text="Better Neighbors")
        elif mode == "beam":
            self.left_primary_label.config(text="Current_State_set")
            self.left_secondary_label.config(text="Neighbor_States")
            self.better_label.config(text="Selected k Best States")
        else:
            self.left_primary_label.config(text="Frontier")
            self.left_secondary_label.config(text="Reached")
            self.better_label.config(text="Better Neighbors")

    def show_current_state(self, state, heuristic=None):
        self.frontier_box.delete("1.0", tk.END)
        if state is None:
            return
        self.frontier_box.insert(tk.END, self.format_state_with_heuristic(state, heuristic))

    def show_next_state(self, state, heuristic=None):
        self.reached_box.delete("1.0", tk.END)
        if state is None:
            return
        self.reached_box.insert(tk.END, self.format_state_with_heuristic(state, heuristic))

    def format_better_neighbor_item(self, item):
        state = item
        h_cost = None

        if isinstance(item, dict):
            state = item.get("state", item)
            h_cost = item.get("h")
        elif isinstance(item, tuple) and len(item) == 2 and isinstance(item[0], tuple):
            state, h_cost = item

        text = ""
        if h_cost is not None:
            text += f"h = {h_cost}\n"
        text += self.format_state(state)
        return text

    def show_better_neighbors(self, neighbors):
        self.better_box.delete("1.0", tk.END)
        for i, item in enumerate(neighbors, 1):
            self.better_box.insert(tk.END, f"[{i}]\n")
            self.better_box.insert(tk.END, self.format_better_neighbor_item(item))
            self.better_box.insert(tk.END, "\n")

    def update_board(self, state):
        for i, value in enumerate(state):
            if value == 0:
                self.cells[i].config(text="", bg=self.EMPTY_CELL)
            else:
                self.cells[i].config(text=str(value), bg=self.CELL)

    def update_status(self, text):
        self.status_label.config(text=text)

    def update_step_info(self, current, total):
        self.step_label.config(text=f"Bước: {current}/{total}")

    def clear_tree(self):
        self.tree_canvas.delete("all")

    def draw_solution_tree(self, path, moves):
        self.clear_tree()

        if not path:
            return

        canvas = self.tree_canvas
        start_x = 80
        start_y = 40
        vertical_gap = 135
        board_size = 22

        for i, state in enumerate(path):
            x = start_x
            y = start_y + i * vertical_gap

            for r in range(3):
                for c in range(3):
                    idx = r * 3 + c
                    val = state[idx]

                    x1 = x + c * board_size
                    y1 = y + r * board_size
                    x2 = x1 + board_size
                    y2 = y1 + board_size

                    fill = self.EMPTY_CELL if val == 0 else self.CELL

                    canvas.create_rectangle(
                        x1, y1, x2, y2,
                        fill=fill,
                        outline=self.BORDER,
                        width=1,
                    )

                    if val != 0:
                        canvas.create_text(
                            (x1 + x2) / 2,
                            (y1 + y2) / 2,
                            text=str(val),
                            font=("Arial", 9, "bold"),
                            fill=self.TEXT,
                        )

            canvas.create_text(
                x + 90,
                y + 20,
                text=f"Bước {i}",
                font=("Arial", 11, "bold"),
                anchor="w",
                fill=self.ACCENT_DARK,
            )

            if i < len(path) - 1:
                next_y = start_y + (i + 1) * vertical_gap

                canvas.create_line(
                    x + 33,
                    y + 66,
                    x + 33,
                    next_y,
                    arrow=tk.LAST,
                    width=2,
                    fill=self.ACCENT,
                )

                if i < len(moves):
                    canvas.create_text(
                        x + 55,
                        (y + next_y) / 2 + 10,
                        text=moves[i],
                        font=("Arial", 10, "bold"),
                        fill=self.ACCENT_DARK,
                    )

        canvas.configure(scrollregion=canvas.bbox("all"))


    def _update_beam_k_visibility(self, event=None):
        algorithm = self.algorithm_var.get().upper()
        is_beam = "LOCAL BEAM SEARCH" in algorithm or "BEAM SEARCH" in algorithm or "LOCAL BEAM" in algorithm

        if is_beam:
            if not self.beam_k_row.winfo_ismapped():
                self.beam_k_row.pack(anchor="w", pady=(0, 10))
        else:
            if self.beam_k_row.winfo_ismapped():
                self.beam_k_row.pack_forget()

    def set_callbacks(self, solve, prev, next_):
        self.solve_button.config(command=solve)
        self.prev_button.config(command=prev)
        self.next_button.config(command=next_)
