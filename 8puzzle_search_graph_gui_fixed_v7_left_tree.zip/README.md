
# 8-Puzzle Search Explorer

Ứng dụng GUI minh hoạ 3 cách biểu diễn / giải bài toán 8-puzzle:

- **AND-OR Search** trong môi trường không xác định
- **CSP Backtracking (8-Puzzle)**
- **Forward Checking (8-Puzzle)**

## Cách chạy

```bash
python main.py
```

## Ý tưởng

- Ở chế độ **AND-OR**, mỗi hành động của 8-puzzle có nhiều outcome nên cây sẽ có nút OR và AND.
- Ở chế độ **CSP Backtracking**, bài toán được diễn giải như một chuỗi trạng thái cần gán lần lượt.
- Ở chế độ **Forward Checking**, thuật toán dùng heuristic Manhattan để cắt nhánh sớm.

## Ghi chú

Nếu muốn cây hiển thị gần giống mẫu tay, hãy dùng trạng thái đầu gần trạng thái đích để cây không quá lớn.
