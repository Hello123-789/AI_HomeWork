
from __future__ import annotations

from typing import Any, Dict, List, Optional, Set, Tuple

from model import PuzzleModel, SearchResult, State


def _state_node(state: State, *, title: Optional[str] = None, status: str = "normal") -> Dict[str, Any]:
    return {
        "kind": "state",
        "title": title or "",
        "state": state,
        "status": status,
        "children": [],
    }


def _decision_node(label: str, *, status: str = "normal") -> Dict[str, Any]:
    return {
        "kind": "decision",
        "label": label,
        "status": status,
        "children": [],
    }


def _prune_node(label: str) -> Dict[str, Any]:
    return {
        "kind": "prune",
        "label": label,
        "children": [],
    }


def _path_key(path: List[State]) -> Tuple[State, ...]:
    return tuple(path)


def backtracking(model: PuzzleModel, depth_limit: int = 20) -> SearchResult:
    explored = 0

    def dfs(state: State, depth: int, path: List[State], moves: List[str], parent_node: Dict[str, Any]):
        nonlocal explored
        explored += 1

        node = _state_node(state, title=f"Depth {depth}", status="goal" if model.is_goal(state) else "normal")
        parent_node["children"].append(node)

        if model.is_goal(state):
            return node, path + [state], moves

        if depth >= depth_limit or state in path:
            node["status"] = "fail"
            return None

        for action, nxt in model.get_neighbors(state):
            decision = _decision_node(action)
            node["children"].append(decision)
            result = dfs(nxt, depth + 1, path + [state], moves + [action], decision)
            if result is not None:
                return result

        node["status"] = "fail"
        return None

    root = {"kind": "root", "label": "START", "children": []}
    result = dfs(model.start_state, 0, [], [], root)

    if result is None:
        return SearchResult(
            success=False,
            path=[],
            labels=[],
            explored=explored,
            message="Không tìm thấy lời giải bằng Backtracking trong giới hạn độ sâu.",
            kind="puzzle",
            details={"tree": root},
        )

    _, path, labels = result
    return SearchResult(
        success=True,
        path=path,
        labels=labels,
        explored=explored,
        message="Backtracking thành công.",
        kind="puzzle",
        details={"tree": root},
    )


def forward_backtracking(model: PuzzleModel, depth_limit: int = 20) -> SearchResult:
    explored = 0

    def dfs(state: State, depth: int, path: List[State], moves: List[str], parent_node: Dict[str, Any]):
        nonlocal explored
        explored += 1

        node = _state_node(state, title=f"Depth {depth} | h={model.heuristic(state)}", status="goal" if model.is_goal(state) else "normal")
        parent_node["children"].append(node)

        if model.is_goal(state):
            return node, path + [state], moves

        if depth >= depth_limit or state in path:
            node["status"] = "fail"
            return None

        remaining = depth_limit - depth
        if model.heuristic(state) > remaining:
            node["status"] = "prune"
            node["title"] = f"Depth {depth} | h={model.heuristic(state)} > remain {remaining}"
            return None

        candidates: List[Tuple[int, str, State]] = []
        seen_children: Set[State] = set()
        for action, nxt in model.get_neighbors(state):
            if nxt in path or nxt in seen_children:
                continue
            seen_children.add(nxt)
            candidates.append((model.heuristic(nxt), action, nxt))

        candidates.sort(key=lambda x: (x[0], x[1]))

        for h, action, nxt in candidates:
            decision = _decision_node(f"{action} (h={h})")
            node["children"].append(decision)
            result = dfs(nxt, depth + 1, path + [state], moves + [action], decision)
            if result is not None:
                return result

        node["status"] = "fail"
        return None

    root = {"kind": "root", "label": "START", "children": []}
    result = dfs(model.start_state, 0, [], [], root)

    if result is None:
        return SearchResult(
            success=False,
            path=[],
            labels=[],
            explored=explored,
            message="Không tìm thấy lời giải bằng Forward Backtracking trong giới hạn độ sâu.",
            kind="puzzle",
            details={"tree": root},
        )

    _, path, labels = result
    return SearchResult(
        success=True,
        path=path,
        labels=labels,
        explored=explored,
        message="Forward Backtracking thành công.",
        kind="puzzle",
        details={"tree": root},
    )



def _shortest_path(model: PuzzleModel, start: State, goal: State):
    from collections import deque

    if start == goal:
        return [start], []

    queue = deque([start])
    parents: Dict[State, Optional[State]] = {start: None}
    action_from_parent: Dict[State, str] = {}

    while queue:
        state = queue.popleft()
        for action, nxt in model.get_neighbors(state):
            if nxt in parents:
                continue
            parents[nxt] = state
            action_from_parent[nxt] = action
            if nxt == goal:
                path = [goal]
                labels = [action_from_parent[goal]]
                cur = goal
                while parents[cur] is not None:
                    cur = parents[cur]
                    path.append(cur)
                    if parents[cur] is not None:
                        labels.append(action_from_parent[cur])
                path.reverse()
                labels.reverse()
                return path, labels
            queue.append(nxt)

    return None, None


def and_or_search(model: PuzzleModel, depth_limit: int = 12) -> SearchResult:
    """
    Phiên bản minh hoạ AND-OR:
    - dùng một đường đi ngắn nhất làm nhánh 'intended'
    - thêm một nhánh 'slip' để cây có dạng OR/AND giống mẫu
    - mục tiêu là hiển thị đúng cấu trúc cây cho môi trường không xác định
    """
    explored = 0

    path, labels = _shortest_path(model, model.start_state, model.goal_state)
    if not path:
        return SearchResult(
            success=False,
            path=[],
            labels=[],
            explored=0,
            message="Không tìm thấy đường đi từ start tới goal.",
            kind="puzzle",
            details={"tree": {"kind": "root", "label": "START", "children": []}},
        )

    def build_tree(state: State, depth: int, path_stack: List[State]) -> Dict[str, Any]:
        nonlocal explored
        explored += 1

        node = _state_node(state, title=f"OR depth {depth}", status="goal" if model.is_goal(state) else "normal")
        if model.is_goal(state) or depth >= depth_limit:
            return node

        # chọn action nằm trên đường đi ngắn nhất nếu có
        sub_path, sub_labels = _shortest_path(model, state, model.goal_state)
        if not sub_path or len(sub_path) < 2:
            node["status"] = "fail"
            return node

        intended_action = sub_labels[0]
        intended_state = sub_path[1]

        action_node = _decision_node(f"OR: {intended_action}")
        node["children"].append(action_node)

        # outcome 1: intended
        outcome_node = _decision_node(f"AND outcome: {intended_action}")
        action_node["children"].append(outcome_node)
        if intended_state not in path_stack:
            outcome_node["children"].append(build_tree(intended_state, depth + 1, path_stack + [state]))

        # outcome 2: slip (một trạng thái kề khác, ưu tiên heuristic tốt nhất)
        alt_candidates: List[Tuple[int, str, State]] = []
        for move, nxt in model.get_neighbors(state):
            if nxt == intended_state:
                continue
            alt_candidates.append((model.heuristic(nxt), move, nxt))
        alt_candidates.sort(key=lambda x: (x[0], x[1]))
        if alt_candidates:
            _, alt_move, alt_state = alt_candidates[0]
            slip_node = _decision_node(f"AND outcome: SLIP-{alt_move}")
            action_node["children"].append(slip_node)
            if alt_state not in path_stack:
                slip_node["children"].append(build_tree(alt_state, depth + 1, path_stack + [state]))

        return node

    tree = build_tree(model.start_state, 0, [])
    return SearchResult(
        success=True,
        path=path,
        labels=labels,
        explored=explored,
        message="AND-OR Search hoàn tất (cây minh hoạ môi trường không xác định).",
        kind="puzzle",
        details={"tree": tree},
    )



def csp_backtracking(model: PuzzleModel, depth_limit: int = 20) -> SearchResult:
    """
    Diễn giải 8-puzzle theo kiểu CSP trên chuỗi trạng thái:
    mỗi bước là một biến, miền giá trị là các trạng thái đi được từ trạng thái trước.
    """
    explored = 0

    def dfs(state: State, depth: int, path: List[State], moves: List[str], parent_node: Dict[str, Any]):
        nonlocal explored
        explored += 1

        node = _state_node(state, title=f"Step {depth}", status="goal" if model.is_goal(state) else "normal")
        parent_node["children"].append(node)

        if model.is_goal(state):
            return node, path + [state], moves

        if depth >= depth_limit or state in path:
            node["status"] = "fail"
            return None

        # Backtracking: thử từng giá trị trong miền theo thứ tự gốc.
        for action, nxt in model.get_neighbors(state):
            branch = _decision_node(f"TRY {action}")
            node["children"].append(branch)
            result = dfs(nxt, depth + 1, path + [state], moves + [action], branch)
            if result is not None:
                return result

        node["status"] = "fail"
        return None

    root = {"kind": "root", "label": "START", "children": []}
    result = dfs(model.start_state, 0, [], [], root)

    if result is None:
        return SearchResult(
            success=False,
            path=[],
            labels=[],
            explored=explored,
            message="Không tìm thấy nghiệm bằng CSP Backtracking trong giới hạn độ sâu.",
            kind="csp",
            details={"tree": root},
        )

    _, path, labels = result
    return SearchResult(
        success=True,
        path=path,
        labels=labels,
        explored=explored,
        message="CSP Backtracking thành công.",
        kind="csp",
        details={"tree": root},
    )


def forward_checking(model: PuzzleModel, depth_limit: int = 20) -> SearchResult:
    """
    Forward Checking cho 8-puzzle:
    - dùng heuristic Manhattan như một ràng buộc nhìn trước
    - cắt nhánh nếu trạng thái hiện tại chắc chắn không thể về đích trong số bước còn lại
    """
    explored = 0

    def dfs(state: State, depth: int, path: List[State], moves: List[str], parent_node: Dict[str, Any]):
        nonlocal explored
        explored += 1

        h = model.heuristic(state)
        node = _state_node(state, title=f"Step {depth} | h={h}", status="goal" if model.is_goal(state) else "normal")
        parent_node["children"].append(node)

        if model.is_goal(state):
            return node, path + [state], moves

        if depth >= depth_limit or state in path:
            node["status"] = "fail"
            return None

        remaining = depth_limit - depth
        if h > remaining:
            node["status"] = "prune"
            node["title"] = f"Step {depth} | h={h} > remain {remaining}"
            return None

        candidates: List[Tuple[int, str, State]] = []
        seen_children: Set[State] = set()
        for action, nxt in model.get_neighbors(state):
            if nxt in path or nxt in seen_children:
                continue
            seen_children.add(nxt)
            candidates.append((model.heuristic(nxt), action, nxt))
        candidates.sort(key=lambda x: (x[0], x[1]))

        for child_h, action, nxt in candidates:
            if child_h > remaining - 1:
                branch = _decision_node(f"PRUNE {action} (h={child_h})", status="prune")
                node["children"].append(branch)
                branch["children"].append(_prune_node("Không đủ bước còn lại"))
                continue

            branch = _decision_node(f"TRY {action} (h={child_h})")
            node["children"].append(branch)
            result = dfs(nxt, depth + 1, path + [state], moves + [action], branch)
            if result is not None:
                return result

        node["status"] = "fail"
        return None

    root = {"kind": "root", "label": "START", "children": []}
    result = dfs(model.start_state, 0, [], [], root)

    if result is None:
        return SearchResult(
            success=False,
            path=[],
            labels=[],
            explored=explored,
            message="Không tìm thấy nghiệm bằng Forward Checking trong giới hạn độ sâu.",
            kind="csp",
            details={"tree": root},
        )

    _, path, labels = result
    return SearchResult(
        success=True,
        path=path,
        labels=labels,
        explored=explored,
        message="Forward Checking thành công.",
        kind="csp",
        details={"tree": root},
    )
