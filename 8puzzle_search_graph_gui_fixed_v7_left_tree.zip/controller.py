from __future__ import annotations

from algorithms import and_or_search, backtracking, csp_backtracking, forward_backtracking, forward_checking
from model import PuzzleModel


class PuzzleController:
    def __init__(self, view):
        self.view = view
        self.result = None
        self.current_index = 0
        self._path = []
        self._labels = []

    def _parse_board(self, text):
        tokens = text.replace(",", " ").split()
        if len(tokens) != 9:
            raise ValueError("Mỗi bảng phải có đúng 9 số.")
        nums = [int(t) for t in tokens]
        if sorted(nums) != list(range(9)):
            raise ValueError("Bảng phải chứa các số từ 0 đến 8, mỗi số đúng 1 lần.")
        return tuple(nums)

    def _refresh_current(self):
        if not self._path:
            return
        current = self._path[self.current_index]
        self.view.update_board(current)
        self.view.update_step_info(self.current_index + 1, len(self._path))

    def solve(self):
        mode = self.view.algorithm_var.get()

        try:
            start_state, goal_state = self.view.get_puzzle_states()
            depth_limit = self.view.get_depth_limit()
            model = PuzzleModel(start_state, goal_state, slip_enabled=True)

            if not model.is_solvable():
                self._reset_with_message("Trạng thái này không thể giải được.", start_state)
                return

            if mode == "AND-OR Search":
                result = and_or_search(model, depth_limit=depth_limit)
            elif mode == "CSP Backtracking (8-Puzzle)":
                result = csp_backtracking(model, depth_limit=depth_limit)
            else:
                result = forward_checking(model, depth_limit=depth_limit)

        except Exception as exc:
            self._reset_with_message(f"Lỗi nhập liệu: {exc}")
            return

        self.result = result
        self._path = result.path[:] if result.path else []
        self._labels = result.labels[:]
        self.current_index = 0

        self.view.update_status(result.message)
        self.view.draw_solution_tree(result)

        if result.success and self._path:
            self.view.update_step_info(1, len(self._path))
            self.view.update_board(self._path[0])
        else:
            self.view.update_step_info(0, 0)
            start_state, _ = self.view.get_puzzle_states()
            self.view.update_board(start_state)

    def _reset_with_message(self, message, board=None):
        self.result = None
        self._path = []
        self._labels = []
        self.current_index = 0
        self.view.update_status(message)
        self.view.update_step_info(0, 0)
        self.view.clear_tree()
        if board is not None:
            self.view.update_board(board)
        else:
            self.view.update_board({})

    def prev_step(self):
        if not self._path:
            return
        self.current_index = max(0, self.current_index - 1)
        self._refresh_current()
        if self.result:
            self.view.update_status(self.result.message)

    def next_step(self):
        if not self._path:
            return
        self.current_index = min(len(self._path) - 1, self.current_index + 1)
        self._refresh_current()
        if self.result:
            self.view.update_status(self.result.message)
