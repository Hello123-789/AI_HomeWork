
import tkinter as tk

from controller import PuzzleController
from view import PuzzleView


def main():
    root = tk.Tk()
    view = PuzzleView(root)
    controller = PuzzleController(view)
    view.set_callbacks(controller.solve, controller.prev_step, controller.next_step)
    root.mainloop()


if __name__ == "__main__":
    main()
