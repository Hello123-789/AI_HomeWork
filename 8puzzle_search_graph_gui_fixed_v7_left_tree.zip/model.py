
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

State = Tuple[int, ...]
DEFAULT_GOAL_STATE: State = (1, 2, 3, 4, 5, 6, 7, 8, 0)


@dataclass
class SearchResult:
    success: bool
    path: List[Any]
    labels: List[str]
    explored: int
    message: str
    kind: str = "generic"
    details: Dict[str, Any] = field(default_factory=dict)


class PuzzleModel:
    def __init__(
        self,
        start_state: State,
        goal_state: State = DEFAULT_GOAL_STATE,
        slip_enabled: bool = False,
    ):
        self.start_state = start_state
        self.goal_state = goal_state
        self.slip_enabled = slip_enabled

    def is_goal(self, state: State) -> bool:
        return state == self.goal_state

    def is_solvable(self, state: Optional[State] = None, goal_state: Optional[State] = None) -> bool:
        state = state or self.start_state
        goal_state = goal_state or self.goal_state

        def inversion_count(values: State) -> int:
            arr = [v for v in values if v != 0]
            inv = 0
            for i in range(len(arr)):
                for j in range(i + 1, len(arr)):
                    if arr[i] > arr[j]:
                        inv += 1
            return inv

        return inversion_count(state) % 2 == inversion_count(goal_state) % 2

    def get_neighbors(self, state: State):
        zero = state.index(0)
        row, col = divmod(zero, 3)
        neighbors = []

        def swap(i: int, j: int) -> State:
            arr = list(state)
            arr[i], arr[j] = arr[j], arr[i]
            return tuple(arr)

        if row > 0:
            neighbors.append(("UP", swap(zero, zero - 3)))
        if row < 2:
            neighbors.append(("DOWN", swap(zero, zero + 3)))
        if col > 0:
            neighbors.append(("LEFT", swap(zero, zero - 1)))
        if col < 2:
            neighbors.append(("RIGHT", swap(zero, zero + 1)))

        return neighbors

    def legal_actions(self, state: State) -> List[str]:
        return [action for action, _ in self.get_neighbors(state)]

    def apply_action(self, state: State, action: str) -> Optional[State]:
        action = action.upper()
        for move, nxt in self.get_neighbors(state):
            if move == action:
                return nxt
        return None

    def nondeterministic_successors(self, state: State, action: str):
        """
        Mô phỏng môi trường không xác định theo kiểu dễ minh hoạ trên cây:
        - outcome chính: thực hiện đúng hành động
        - outcome phụ: một bước trượt khác nhưng vẫn ưu tiên trạng thái có heuristic nhỏ hơn

        Cách này giữ cho AND-OR tree rõ ràng và dễ tìm được kế hoạch trong demo.
        """
        action = action.upper()
        current_h = self.heuristic(state)

        outcomes = []
        seen = set()

        intended = self.apply_action(state, action)
        if intended is not None:
            outcomes.append((action, intended))
            seen.add(intended)

        # Tạo một outcome phụ khác nhưng ưu tiên tiến gần goal hơn để tránh cây nổ quá lớn.
        alt_candidates = []
        for move, nxt in self.get_neighbors(state):
            if move == action or nxt in seen:
                continue
            h = self.heuristic(nxt)
            alt_candidates.append((h, move, nxt))

        alt_candidates.sort(key=lambda x: (x[0], x[1]))
        for h, move, nxt in alt_candidates:
            if h <= current_h:
                outcomes.append((f"SLIP-{move}", nxt))
                break

        if not outcomes:
            # fallback an toàn
            outcomes.append(("STAY", state))

        return outcomes

    def heuristic(self, state: State) -> int:
        goal_positions = {value: i for i, value in enumerate(self.goal_state)}
        total = 0
        for i, value in enumerate(state):
            if value == 0:
                continue
            goal_idx = goal_positions[value]
            r1, c1 = divmod(i, 3)
            r2, c2 = divmod(goal_idx, 3)
            total += abs(r1 - r2) + abs(c1 - c2)
        return total

    @staticmethod
    def format_state(state: State) -> str:
        rows = []
        for i in range(0, 9, 3):
            row = []
            for x in state[i:i + 3]:
                row.append(" " if x == 0 else str(x))
            rows.append(" ".join(row))
        return "\n".join(rows)

    @staticmethod
    def compact_state(state: State) -> str:
        return "".join("0" if x == 0 else str(x) for x in state)
