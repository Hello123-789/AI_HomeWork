from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Dict, Any

from model import PuzzleModel


class PuzzleView:
    BG = "#f4f7fb"
    PANEL = "#ffffff"
    PANEL_ALT = "#f8fbff"
    ACCENT = "#4f6ef7"
    ACCENT_DARK = "#324dc7"
    TEXT = "#1f2937"
    MUTED = "#64748b"
    BORDER = "#d7def0"
    EMPTY_CELL = "#dfe6f3"
    CELL = "#ffffff"
    HIGHLIGHT = "#e7efff"
    PRUNE_FILL = "#fff1f2"
    GOAL_FILL = "#dcfce7"

    def __init__(self, root):
        self.root = root
        self.root.title("8-Puzzle Search Explorer")
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        width = max(1280, screen_w - 20)
        height = max(720, screen_h - 80)
        self.root.geometry(f"{width}x{height}")
        self.root.minsize(1180, 720)
        try:
            self.root.state("zoomed")
        except tk.TclError:
            pass
        self.root.configure(bg=self.BG)

        self.current_problem = "AND-OR Search"
        self.cells = []
        self._tree_nodes = []
        self._current_board_state = None
        self.setup_style()
        self.build_ui()
        self.show_problem_mode("AND-OR Search")
        self.update_status("Sẵn sàng.")
        self.update_step_info(0, 0)

    def setup_style(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", background=self.BG, foreground=self.TEXT, font=("Segoe UI", 10))
        style.configure("App.TFrame", background=self.BG)
        style.configure("Card.TFrame", background=self.PANEL)
        style.configure("Section.TLabel", background=self.BG, foreground=self.TEXT, font=("Segoe UI", 11, "bold"))
        style.configure("Title.TLabel", background=self.BG, foreground=self.ACCENT_DARK, font=("Segoe UI", 16, "bold"))
        style.configure("Info.TLabel", background=self.BG, foreground=self.MUTED, font=("Segoe UI", 10))
        style.configure("Accent.TButton", background=self.ACCENT, foreground="white", padding=(14, 8), borderwidth=0)
        style.map("Accent.TButton", background=[("active", self.ACCENT_DARK)], foreground=[("disabled", "#dbe4ff")])
        style.configure("Neutral.TButton", background="#e8edf8", foreground=self.TEXT, padding=(14, 8), borderwidth=0)
        style.map("Neutral.TButton", background=[("active", self.HIGHLIGHT), ("pressed", self.HIGHLIGHT)])
        style.configure("Algo.TCombobox", padding=6)

    def build_ui(self):
        self.root.rowconfigure(0, weight=1)
        self.root.columnconfigure(0, weight=1)

        outer = ttk.Frame(self.root, style="App.TFrame")
        outer.grid(row=0, column=0, sticky="nsew")
        outer.rowconfigure(0, weight=1)
        outer.columnconfigure(0, weight=1)

        self.outer_canvas = tk.Canvas(outer, bg=self.BG, highlightthickness=0, bd=0)
        self.outer_canvas.grid(row=0, column=0, sticky="nsew")
        outer_scroll_y = ttk.Scrollbar(outer, orient="vertical", command=self.outer_canvas.yview)
        outer_scroll_y.grid(row=0, column=1, sticky="ns")
        outer_scroll_x = ttk.Scrollbar(outer, orient="horizontal", command=self.outer_canvas.xview)
        outer_scroll_x.grid(row=1, column=0, sticky="ew")
        self.outer_canvas.configure(yscrollcommand=outer_scroll_y.set, xscrollcommand=outer_scroll_x.set)

        self.content = ttk.Frame(self.outer_canvas, style="App.TFrame")
        self.content_window = self.outer_canvas.create_window((0, 0), window=self.content, anchor="nw")

        def _sync_scrollregion(_event=None):
            self.outer_canvas.configure(scrollregion=self.outer_canvas.bbox("all"))

        def _sync_window(event):
            self.outer_canvas.itemconfigure(self.content_window, width=event.width, height=event.height)

        self.content.bind("<Configure>", _sync_scrollregion)
        self.outer_canvas.bind("<Configure>", _sync_window)

        main = self.content
        main.columnconfigure(0, weight=0)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(2, weight=1)

        header = ttk.Frame(main, style="App.TFrame")
        header.grid(row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=(10, 0))
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text="8-Puzzle Search Explorer", style="Title.TLabel").grid(row=0, column=0, sticky="w", padx=8, pady=(0, 4))
        ttk.Label(
            header,
            text="Ba chế độ hiển thị: AND-OR Search cho môi trường không xác định, CSP Backtracking và Forward Checking cho 8-puzzle.",
            style="Info.TLabel",
        ).grid(row=1, column=0, sticky="w", padx=8, pady=(0, 8))

        left_panel = ttk.Frame(main, style="Card.TFrame")
        left_panel.grid(row=1, column=0, rowspan=2, sticky="nsew", padx=(10, 8), pady=(0, 10))
        left_panel.columnconfigure(0, weight=1)

        ttk.Label(left_panel, text="Chọn thuật toán", style="Section.TLabel").grid(row=0, column=0, sticky="w", padx=16, pady=(14, 0))
        self.algorithm_var = tk.StringVar(value="AND-OR Search")
        self.algorithm_combo = ttk.Combobox(
            left_panel,
            textvariable=self.algorithm_var,
            values=["AND-OR Search", "CSP Backtracking (8-Puzzle)", "Forward Checking (8-Puzzle)"],
            state="readonly",
            width=30,
            style="Algo.TCombobox",
        )
        self.algorithm_combo.grid(row=1, column=0, sticky="ew", padx=16, pady=(6, 8))
        self.algorithm_combo.bind("<<ComboboxSelected>>", self._on_algorithm_change)

        self.mode_hint = ttk.Label(left_panel, text="", style="Info.TLabel", justify="left", wraplength=320)
        self.mode_hint.grid(row=2, column=0, sticky="w", padx=16, pady=(0, 8))

        inputs_card = ttk.Frame(left_panel, style="Card.TFrame")
        inputs_card.grid(row=3, column=0, sticky="ew", padx=16, pady=(8, 6))
        inputs_card.columnconfigure(0, weight=1)
        inputs_card.columnconfigure(1, weight=1)

        left_inputs = ttk.Frame(inputs_card, style="Card.TFrame")
        left_inputs.grid(row=0, column=0, sticky="nw", padx=(0, 18), pady=8)

        ttk.Label(left_inputs, text="Start state", style="Section.TLabel").grid(row=0, column=0, sticky="w")
        self.start_text = tk.Text(
            left_inputs, width=16, height=5, font=("Consolas", 11),
            bg="#ffffff", relief="flat", highlightthickness=1, highlightbackground=self.BORDER, padx=8, pady=8,
        )
        self.start_text.grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.start_text.insert("1.0", "1 2 3\n4 0 5\n7 8 6")

        ttk.Label(left_inputs, text="Goal state", style="Section.TLabel").grid(row=2, column=0, sticky="w", pady=(12, 0))
        self.goal_text = tk.Text(
            left_inputs, width=16, height=5, font=("Consolas", 11),
            bg="#ffffff", relief="flat", highlightthickness=1, highlightbackground=self.BORDER, padx=8, pady=8,
        )
        self.goal_text.grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.goal_text.insert("1.0", "1 2 3\n4 5 6\n7 8 0")

        right_inputs = ttk.Frame(inputs_card, style="Card.TFrame")
        right_inputs.grid(row=0, column=1, sticky="n", padx=10, pady=8)

        ttk.Label(right_inputs, text="Depth limit", style="Section.TLabel").grid(row=0, column=0, sticky="w")
        self.depth_entry = ttk.Entry(right_inputs, width=10)
        self.depth_entry.insert(0, "18")
        self.depth_entry.grid(row=1, column=0, sticky="w", pady=(6, 10))

        self.puzzle_note = ttk.Label(
            right_inputs,
            text="AND-OR: một hành động có nhiều kết quả.\nCSP Backtracking: thử giá trị theo thứ tự.\nForward Checking: dùng heuristic để cắt nhánh sớm.",
            style="Info.TLabel",
            justify="left",
            wraplength=220,
        )
        self.puzzle_note.grid(row=2, column=0, sticky="w", pady=(8, 0))

        button_frame = ttk.Frame(left_panel, style="App.TFrame")
        button_frame.grid(row=4, column=0, pady=(6, 10))

        self.solve_button = ttk.Button(button_frame, text="Solve", style="Accent.TButton")
        self.solve_button.pack(side="left", padx=6)
        self.prev_button = ttk.Button(button_frame, text="Prev", style="Neutral.TButton")
        self.prev_button.pack(side="left", padx=6)
        self.next_button = ttk.Button(button_frame, text="Next", style="Neutral.TButton")
        self.next_button.pack(side="left", padx=6)

        self.status_label = ttk.Label(left_panel, text="", style="Info.TLabel")
        self.status_label.grid(row=5, column=0, sticky="w", padx=16, pady=(0, 2))
        self.step_label = ttk.Label(left_panel, text="", style="Info.TLabel")
        self.step_label.grid(row=6, column=0, sticky="w", padx=16, pady=(0, 10))

        # Placeholder canvas kept for compatibility; current state is no longer shown.
        self.visual_canvas = tk.Canvas(self.content, width=1, height=1, highlightthickness=0, bd=0)

        right_panel = ttk.Frame(main, style="Card.TFrame")
        right_panel.grid(row=1, column=1, rowspan=2, sticky="nsew", padx=(8, 10), pady=(0, 10))
        right_panel.columnconfigure(0, weight=1)
        right_panel.rowconfigure(1, weight=1)

        ttk.Label(right_panel, text="Search tree", style="Section.TLabel").grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        tree_frame = ttk.Frame(right_panel, style="Card.TFrame")
        tree_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 8))
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        self.tree_canvas = tk.Canvas(
            tree_frame,
            bg=self.PANEL_ALT,
            width=1200,
            height=760,
            highlightthickness=1,
            highlightbackground=self.BORDER,
            bd=0,
        )
        self.tree_canvas.grid(row=0, column=0, sticky="nsew")
        tree_scroll_y = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree_canvas.yview)
        tree_scroll_y.grid(row=0, column=1, sticky="ns")
        tree_scroll_x = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.tree_canvas.xview)
        tree_scroll_x.grid(row=1, column=0, sticky="ew")
        self.tree_canvas.configure(yscrollcommand=tree_scroll_y.set, xscrollcommand=tree_scroll_x.set)
    def _on_algorithm_change(self, event=None):
        self.show_problem_mode(self.algorithm_var.get())

    def show_problem_mode(self, mode: str):
        self.current_problem = mode
        if mode == "AND-OR Search":
            self.mode_hint.config(text="AND-OR: trong môi trường không xác định, mỗi hành động có nhiều outcome.")
        elif mode == "CSP Backtracking (8-Puzzle)":
            self.mode_hint.config(text="CSP Backtracking: duyệt các trạng thái như các giá trị của biến theo thứ tự.")
        else:
            self.mode_hint.config(text="Forward Checking: thử trạng thái tốt hơn trước và cắt nhánh sớm bằng heuristic.")

    def get_depth_limit(self) -> int:
        raw = self.depth_entry.get().strip()
        try:
            return max(1, int(raw))
        except Exception:
            return 18

    def get_puzzle_states(self):
        def parse(text):
            tokens = text.replace(",", " ").split()
            if len(tokens) != 9:
                raise ValueError("Mỗi bảng phải có đúng 9 số.")
            nums = [int(t) for t in tokens]
            if sorted(nums) != list(range(9)):
                raise ValueError("Bảng phải chứa các số từ 0 đến 8, mỗi số đúng 1 lần.")
            return tuple(nums)

        start_state = parse(self.start_text.get("1.0", "end"))
        goal_text = self.goal_text.get("1.0", "end").strip()
        goal_state = parse(goal_text) if goal_text else tuple(range(1, 9)) + (0,)
        return start_state, goal_state

    def update_board(self, state):
        self._current_board_state = state
        return

    def _draw_puzzle_board(self, state):
        canvas = self.visual_canvas
        start_x, start_y = 30, 42
        cell = 72
        canvas.create_text(30, 20, anchor="w", text="8-Puzzle board", font=("Segoe UI", 12, "bold"), fill=self.ACCENT_DARK)
        for r in range(3):
            for c in range(3):
                idx = r * 3 + c
                val = state[idx]
                x1 = start_x + c * cell
                y1 = start_y + r * cell
                x2 = x1 + cell
                y2 = y1 + cell
                fill = self.EMPTY_CELL if val == 0 else "#fefefe"
                outline = self.ACCENT_DARK if val != 0 else self.BORDER
                canvas.create_rectangle(x1, y1, x2, y2, fill=fill, outline=outline, width=2)
                if val != 0:
                    canvas.create_text((x1 + x2) / 2, (y1 + y2) / 2, text=str(val), font=("Arial", 22, "bold"), fill=self.TEXT)

    def update_status(self, text):
        self.status_label.config(text=text)

    def update_step_info(self, current, total):
        self.step_label.config(text=f"Bước: {current}/{total}" if total else "Bước: 0/0")

    def clear_tree(self):
        self.tree_canvas.delete("all")
        try:
            self.tree_canvas.xview_moveto(0)
            self.tree_canvas.yview_moveto(0)
        except tk.TclError:
            pass

    def draw_solution_tree(self, result):
        self.clear_tree()
        if not result:
            return

        tree = result.details.get("tree")
        if tree:
            self._draw_tree(tree)

    def _draw_tree(self, tree: Dict[str, Any]):
        canvas = self.tree_canvas
        canvas.delete("all")

        def children(node):
            return node.get("children", [])

        positions = {}
        x_gap = 180
        y_gap = 130
        left_margin = 80
        top_margin = 70
        cursor = {"x": left_margin}

        def layout(node, depth=0):
            ch = children(node)
            if not ch:
                x = cursor["x"]
                cursor["x"] += x_gap
            else:
                xs = [layout(c, depth + 1) for c in ch]
                x = sum(xs) / len(xs)
            y = top_margin + depth * y_gap
            positions[id(node)] = (x, y)
            return x

        layout(tree)

        def draw_edges(node):
            x1, y1 = positions[id(node)]
            for ch in children(node):
                x2, y2 = positions[id(ch)]
                canvas.create_line(
                    x1, y1 + self._node_height(node) / 2,
                    x2, y2 - self._node_height(ch) / 2,
                    fill=self.BORDER, width=2,
                )
                draw_edges(ch)

        draw_edges(tree)

        def draw_nodes(node):
            x, y = positions[id(node)]
            kind = node.get("kind", "state")
            if kind == "state" or kind == "root":
                self._draw_state_node(canvas, x, y, node)
            elif kind == "decision":
                self._draw_decision_node(canvas, x, y, node)
            elif kind == "prune":
                self._draw_prune_node(canvas, x, y, node)
            for ch in children(node):
                draw_nodes(ch)

        draw_nodes(tree)

        max_x = max((x for x, _ in positions.values()), default=0) + 260
        max_y = max((y for _, y in positions.values()), default=0) + 160
        canvas.configure(scrollregion=(0, 0, max_x, max_y))
        try:
            canvas.xview_moveto(0)
            canvas.yview_moveto(0)
        except tk.TclError:
            pass

    def _node_height(self, node: Dict[str, Any]) -> int:
        kind = node.get("kind", "state")
        if kind == "decision":
            return 42
        if kind == "prune":
            return 34
        return 92

    def _node_width(self, node: Dict[str, Any]) -> int:
        kind = node.get("kind", "state")
        if kind == "decision":
            return max(90, min(160, 18 + len(node.get("label", "")) * 6))
        if kind == "prune":
            return max(100, min(160, 18 + len(node.get("label", "")) * 6))
        return 135

    def _draw_state_node(self, canvas, x, y, node):
        width = self._node_width(node)
        height = 92
        title = node.get("title", "")
        state = node.get("state")
        status = node.get("status", "normal")

        fill = self.CELL
        if status == "goal":
            fill = self.GOAL_FILL
        elif status == "fail":
            fill = "#fee2e2"
        elif status == "prune":
            fill = "#fef3c7"

        x1, y1 = x - width / 2, y - height / 2
        x2, y2 = x + width / 2, y + height / 2
        canvas.create_rectangle(x1, y1, x2, y2, fill=fill, outline=self.ACCENT_DARK if status == "goal" else self.BORDER, width=2)

        if title:
            canvas.create_text(x, y1 + 14, text=title, font=("Segoe UI", 9, "bold"), fill=self.ACCENT_DARK)

        if state is not None and isinstance(state, tuple):
            text = PuzzleModel.format_state(state)
            canvas.create_text(x, y + 8, text=text, font=("Consolas", 11), fill=self.TEXT, justify="center")

        if node.get("kind") == "root":
            canvas.create_text(x, y, text="START", font=("Segoe UI", 12, "bold"), fill=self.ACCENT_DARK)

    def _draw_decision_node(self, canvas, x, y, node):
        label = node.get("label", "")
        width = self._node_width(node)
        height = 42
        x1, y1 = x - width / 2, y - height / 2
        x2, y2 = x + width / 2, y + height / 2
        status = node.get("status", "normal")
        fill = self.HIGHLIGHT if status == "normal" else self.PRUNE_FILL
        canvas.create_oval(x1, y1, x2, y2, fill=fill, outline=self.ACCENT, width=2)
        canvas.create_text(x, y, text=label, font=("Segoe UI", 9, "bold"), fill=self.TEXT, justify="center")

    def _draw_prune_node(self, canvas, x, y, node):
        label = node.get("label", "PRUNE")
        width = self._node_width(node)
        height = 34
        x1, y1 = x - width / 2, y - height / 2
        x2, y2 = x + width / 2, y + height / 2
        canvas.create_rectangle(x1, y1, x2, y2, fill=self.PRUNE_FILL, outline="#ef4444", width=2)
        canvas.create_text(x, y, text=label, font=("Segoe UI", 9, "bold"), fill="#b91c1c", justify="center")

    def set_callbacks(self, solve, prev, next_):
        self.solve_button.config(command=solve)
        self.prev_button.config(command=prev)
        self.next_button.config(command=next_)

    # Kept for controller compatibility; sidebar was removed.
    def show_frontier(self, frontier):
        return

    def show_reached(self, reached):
        return


# backwards-compatible alias
EightPuzzleView = PuzzleView
